# Automation Edit — Cloud FFmpeg Video Render Worker

This is the cloud rendering backend service for **Automation Edit**. It accepts video project definitions, applies Ken Burns motion transforms (pan & zoom), color grading filters, narration ducking, background music mixing, and burnt-in subtitles using production-grade FFmpeg pipelines.

## Architecture

- **Worker Framework:** Python 3.11 with FastAPI and asynchronous job processing.
- **Rendering Engine:** Native FFmpeg with `libx264`, `libx265`, `fontconfig`, and `amix`.
- **API Endpoints:**
  - `POST /api/render/submit`: Queues a new video rendering job.
  - `GET /api/render/status/{job_id}`: Retrieves progress percentage, current stage, and output artifact URL.
  - `POST /api/render/cancel/{job_id}`: Cancels an active or queued render job.
  - `GET /artifacts/{job_id}.mp4`: Serves the finished rendered documentary MP4 file.
  - `GET /health`: Healthcheck endpoint for load balancers.

## Local Docker Deployment

```bash
docker compose up --build -d
```

The worker will be available at `http://localhost:8080`.

## Google Cloud Run Deployment

1. Build and push container to Google Artifact Registry:
```bash
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/automation-edit-worker .
```

2. Deploy to Cloud Run with 2 CPUs and 2GiB RAM for FFmpeg processing:
```bash
gcloud run deploy automation-edit-worker \
  --image gcr.io/YOUR_PROJECT_ID/automation-edit-worker \
  --platform managed \
  --region us-central1 \
  --memory 2Gi \
  --cpu 2 \
  --timeout 900 \
  --allow-unauthenticated
```
