package com.example

import com.example.data.media.MediaHelper
import com.example.data.model.AspectRatioType
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ResolutionType
import com.example.data.model.VideoCodecType
import com.example.integration.FFmpegRenderPipeline
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AutomationEditLogicTest {

    @Test
    fun testAspectRatioDimensions() {
        assertEquals(16f / 9f, AspectRatioType.LANDSCAPE_16_9.ratio, 0.01f)
        assertEquals(9f / 16f, AspectRatioType.SHORTS_9_16.ratio, 0.01f)
        assertEquals(1f, AspectRatioType.SQUARE_1_1.ratio, 0.01f)
    }

    @Test
    fun testMediaHelperFormatting() {
        assertEquals("00:00", MediaHelper.formatDuration(0f))
        assertEquals("01:15", MediaHelper.formatDuration(75f))
        assertEquals("02:30", MediaHelper.formatDuration(150f))

        assertEquals("500 B", MediaHelper.formatFileSize(500L))
        assertTrue(MediaHelper.formatFileSize(1024L * 512).contains("KB"))
        assertTrue(MediaHelper.formatFileSize(1024L * 1024 * 4).contains("MB"))
    }

    @Test
    fun testFfmpegCommandGeneration() {
        val project = ProjectEntity(
            id = 42L,
            title = "Test Documentary",
            aspectRatio = AspectRatioType.SHORTS_9_16.name,
            resolution = ResolutionType.RES_1080P.name,
            codec = VideoCodecType.CODEC_H264.name,
            voiceAudioFileName = "voice.wav",
            voiceAudioDurationSec = 10f
        )
        val slides = listOf(
            MediaSlideEntity(
                id = 1L,
                projectId = 42L,
                serialOrder = 1,
                imageUri = "https://example.com/1.jpg",
                durationSeconds = 5f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name
            ),
            MediaSlideEntity(
                id = 2L,
                projectId = 42L,
                serialOrder = 2,
                imageUri = "https://example.com/2.jpg",
                durationSeconds = 5f,
                kenBurnsMotion = KenBurnsMotion.PAN_LEFT_TO_RIGHT.name
            )
        )

        val cmd = FFmpegRenderPipeline.buildFullCommand(project, slides)
        assertTrue("Command should contain ffmpeg invocation", cmd.startsWith("ffmpeg"))
        assertTrue("Command should contain zoompan filter", cmd.contains("zoompan"))
        assertTrue("Command should contain concat", cmd.contains("concat=n=2"))
        assertTrue("Command should specify output file with project id", cmd.contains("output_documentary_42.mp4"))
    }

    @Test
    fun testSpeechRecognitionBridgeSentenceTimestamps() = kotlinx.coroutines.runBlocking {
        val bridge = com.example.integration.SpeechRecognitionBridgeImpl()
        val script = "The oceans remain unmapped. Deep trenches hide active hydrothermal vents. Extreme creatures glow in the dark."
        val mockContext = org.robolectric.RuntimeEnvironment.getApplication()

        val alignment = bridge.alignVoiceover(
            context = mockContext,
            audioUriString = null,
            referenceScript = script
        )

        assertEquals(3, alignment.sentences.size)
        assertTrue(alignment.totalDurationMs > 0)

        // Verify zero gaps between sentences
        var previousEnd = 0L
        for (sentence in alignment.sentences) {
            assertEquals("Start of sentence must match previous end for zero gaps", previousEnd, sentence.startMs)
            assertTrue("Sentence duration must be positive", sentence.endMs > sentence.startMs)
            previousEnd = sentence.endMs
        }
        assertEquals("Total alignment must match final sentence end", alignment.totalDurationMs, previousEnd)
    }

    @Test
    fun testGeminiAiSyncEngineSemanticAlignment() = kotlinx.coroutines.runBlocking {
        val engine = com.example.integration.GeminiAiSyncEngineImpl()
        val mockContext = org.robolectric.RuntimeEnvironment.getApplication()

        val project = ProjectEntity(id = 1L, title = "Deep Sea Exploration")
        val slides = listOf(
            MediaSlideEntity(
                id = 1L,
                projectId = 1L,
                serialOrder = 1,
                imageUri = "https://example.com/ocean.jpg",
                title = "Endless Ocean Abyss",
                visualTags = "deep ocean water marine"
            ),
            MediaSlideEntity(
                id = 2L,
                projectId = 1L,
                serialOrder = 2,
                imageUri = "https://example.com/vents.jpg",
                title = "Hydrothermal Chimneys",
                visualTags = "hydrothermal vents spewing minerals geology"
            )
        )

        val sentences = listOf(
            com.example.integration.SpeechRecognitionBridge.SentenceTimestamp(
                sentenceIndex = 0,
                text = "Eighty percent of the oceans remain completely unmapped.",
                startMs = 0L,
                endMs = 6000L,
                wordCount = 8
            ),
            com.example.integration.SpeechRecognitionBridge.SentenceTimestamp(
                sentenceIndex = 1,
                text = "Hydrothermal chimneys spew superheated minerals into the pitch black abyss.",
                startMs = 6000L,
                endMs = 14000L,
                wordCount = 10
            )
        )

        val result = engine.analyzeAndAlign(mockContext, project, slides, sentences)
        assertEquals(2, result.matches.size)

        for (match in result.matches) {
            assertTrue("Confidence score should be between 0.0 and 1.0", match.confidenceScore in 0.0f..1.0f)
            assertTrue("Reasoning should be non-blank", match.reasoning.isNotBlank())
        }
    }

    @Test
    fun testSrtSubtitleGenerator() {
        val slides = listOf(
            MediaSlideEntity(
                id = 1L,
                projectId = 10L,
                serialOrder = 1,
                imageUri = "https://example.com/slide1.jpg",
                durationSeconds = 4.5f,
                captionSnippet = "The deepest part of the ocean is the Mariana Trench."
            ),
            MediaSlideEntity(
                id = 2L,
                projectId = 10L,
                serialOrder = 2,
                imageUri = "https://example.com/slide2.jpg",
                durationSeconds = 6.0f,
                captionSnippet = "Reaching depths of nearly 11,000 meters."
            )
        )

        val srt = com.example.integration.SrtSubtitleGenerator.generateSrt(slides)
        assertTrue(srt.contains("1\n00:00:00,000 --> 00:00:04,500"))
        assertTrue(srt.contains("The deepest part of the ocean is the Mariana Trench."))
        assertTrue(srt.contains("2\n00:00:04,500 --> 00:00:10,500"))
        assertTrue(srt.contains("Reaching depths of nearly 11,000 meters."))
    }

    @Test
    fun testLocalVideoRendererDimensions() {
        // 9:16 Shorts at 1080p
        val (w916, h916) = com.example.integration.LocalVideoRenderer.getDimensions(
            AspectRatioType.SHORTS_9_16,
            ResolutionType.RES_1080P
        )
        assertEquals(1080, w916)
        assertEquals(1920, h916)
        assertEquals(0, w916 % 2) // Must be divisible by 2 for H.264
        assertEquals(0, h916 % 2)

        // 16:9 Long Video at 1080p
        val (w169, h169) = com.example.integration.LocalVideoRenderer.getDimensions(
            AspectRatioType.LANDSCAPE_16_9,
            ResolutionType.RES_1080P
        )
        assertEquals(1920, w169)
        assertEquals(1080, h169)

        // 1:1 Square
        val (w11, h11) = com.example.integration.LocalVideoRenderer.getDimensions(
            AspectRatioType.SQUARE_1_1,
            ResolutionType.RES_1080P
        )
        assertEquals(1080, w11)
        assertEquals(1080, h11)
    }

    @Test
    fun testKenBurnsMotionFilters() {
        for (motion in KenBurnsMotion.values()) {
            val filter = FFmpegRenderPipeline.generateKenBurnsFilter(motion, 24, 5.0f, 1920, 1080)
            assertTrue("Filter for ${motion.name} should be non-empty", filter.isNotBlank())
            if (motion == KenBurnsMotion.STATIC_LOCKED) {
                assertTrue("Static locked should use scale & crop", filter.contains("scale") && filter.contains("crop"))
            } else {
                assertTrue("Motion ${motion.name} should use zoompan", filter.contains("zoompan"))
            }
        }
    }
}
