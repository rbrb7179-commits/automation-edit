package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.media.MediaHelper
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceVariant

data class SampleDocAsset(val title: String, val url: String, val category: String)

val documentaryAssetLibrary = listOf(
    SampleDocAsset("Nebula Galaxy Core", "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80", "Cosmos"),
    SampleDocAsset("Deep Ocean Trench", "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80", "Ocean"),
    SampleDocAsset("Ancient Colosseum", "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800&q=80", "History"),
    SampleDocAsset("Microchip Wafer", "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80", "Tech"),
    SampleDocAsset("Desert Megalith", "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&q=80", "Archival"),
    SampleDocAsset("Submersible Light", "https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?w=800&q=80", "Exploration")
)

@Composable
fun AddMediaDialog(
    existingCount: Int,
    onAddImages: (List<Pair<String, String>>) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Android Photo Picker
    val pickMultipleVisualMedia = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexed { idx, uri ->
                MediaHelper.takePersistableUriPermissionSafe(context, uri)
                val (name, _) = MediaHelper.getFileNameAndSize(context, uri)
                Pair(uri.toString(), name.ifBlank { "Image #${existingCount + idx + 1}" })
            }
            onAddImages(list)
            onDismiss()
        }
    }

    // Storage Access Framework Documents Picker (JPG, PNG, WebP)
    val openSafDocs = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexed { idx, uri ->
                MediaHelper.takePersistableUriPermissionSafe(context, uri)
                val (name, _) = MediaHelper.getFileNameAndSize(context, uri)
                Pair(uri.toString(), name.ifBlank { "Slide #${existingCount + idx + 1}" })
            }
            onAddImages(list)
            onDismiss()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .height(560.dp),
            shape = RoundedCornerShape(12.dp),
            color = CinemaSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(24.dp))
                        Column {
                            Text("Add Images to Timeline", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Import multiple JPG, JPEG, PNG, or WebP images", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Upload Option 1: Modern Photo Picker
                Button(
                    onClick = {
                        pickMultipleVisualMedia.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("open_photo_picker_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CinemaAmberGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select Multiple Images (Photo Picker)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Upload Option 2: Storage Access Framework
                OutlinedButton(
                    onClick = {
                        openSafDocs.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("open_saf_picker_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaCyan),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select via Storage Access Framework", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Or Add Curated Archival References:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(documentaryAssetLibrary) { asset ->
                        Surface(
                            color = CinemaSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clickable {
                                    onAddImages(listOf(Pair(asset.url, asset.title)))
                                    onDismiss()
                                }
                                .testTag("curated_asset_${asset.title.take(5).lowercase()}")
                        ) {
                            Column {
                                AsyncImage(
                                    model = asset.url,
                                    contentDescription = asset.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(80.dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                )
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(asset.title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text(asset.category, color = CinemaCyan, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
