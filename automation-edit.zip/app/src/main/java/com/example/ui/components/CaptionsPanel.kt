package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CaptionPosition
import com.example.data.model.CaptionStyle
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun CaptionsPanel(
    project: ProjectEntity,
    activeSlide: MediaSlideEntity?,
    onCaptionSettingsChanged: (enabled: Boolean, style: CaptionStyle, position: CaptionPosition) -> Unit,
    onSlideCaptionChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentStyle = runCatching {
        CaptionStyle.valueOf(project.captionStyle)
    }.getOrDefault(CaptionStyle.CINEMATIC_GOLD)

    val currentPosition = runCatching {
        CaptionPosition.valueOf(project.captionPosition)
    }.getOrDefault(CaptionPosition.BOTTOM)

    var slideCaptionInput by remember(activeSlide?.captionSnippet) {
        mutableStateOf(activeSlide?.captionSnippet ?: "")
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // Toggle Auto Captions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CinemaSurfaceVariant, RoundedCornerShape(8.dp))
                .border(1.dp, CinemaBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Auto Captions & Subtitles",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = if (project.autoCaptionsEnabled) "Captions will be burned into video on export" else "Captions disabled",
                    color = if (project.autoCaptionsEnabled) CinemaCyan else Color.Gray,
                    fontSize = 10.sp
                )
            }
            Switch(
                checked = project.autoCaptionsEnabled,
                onCheckedChange = { onCaptionSettingsChanged(it, currentStyle, currentPosition) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = CinemaAmberGold,
                    checkedTrackColor = CinemaAmberGold.copy(alpha = 0.4f)
                ),
                modifier = Modifier.testTag("auto_captions_switch")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Caption Typography Style Selector
        Text("Caption Style Preset", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CaptionStyle.values().forEach { style ->
                val isSelected = style == currentStyle
                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaAmberGold else CinemaBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onCaptionSettingsChanged(project.autoCaptionsEnabled, style, currentPosition) }
                        .testTag("caption_style_${style.name.lowercase()}")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = style.title,
                            color = if (isSelected) CinemaAmberGold else Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Position on Screen
        Text("Position on Screen", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CaptionPosition.values().forEach { pos ->
                val isSelected = pos == currentPosition
                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaCyan else CinemaBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onCaptionSettingsChanged(project.autoCaptionsEnabled, currentStyle, pos) }
                        .testTag("caption_pos_${pos.name.lowercase()}")
                ) {
                    Text(
                        text = pos.title,
                        color = if (isSelected) CinemaCyan else Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Slide Caption Override
        if (activeSlide != null) {
            Text(
                text = "Edit Caption for Slide #${activeSlide.serialOrder}",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = slideCaptionInput,
                onValueChange = {
                    slideCaptionInput = it
                    onSlideCaptionChanged(it)
                },
                placeholder = { Text("Enter caption subtitle for this slide...", color = Color.Gray, fontSize = 11.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CinemaBackground,
                    unfocusedContainerColor = CinemaBackground,
                    focusedBorderColor = CinemaAmberGold,
                    unfocusedBorderColor = CinemaBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.LightGray
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("slide_caption_input"),
                shape = RoundedCornerShape(6.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            val context = androidx.compose.ui.platform.LocalContext.current
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CinemaSurfaceVariant, RoundedCornerShape(6.dp))
                    .border(1.dp, CinemaBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("SubRip Format (.srt)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                    Text("Export synchronized captions file", color = Color.Gray, fontSize = 9.sp)
                }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val srt = com.example.integration.SrtSubtitleGenerator.formatSrtTimecode(0) + " --> " +
                                com.example.integration.SrtSubtitleGenerator.formatSrtTimecode((activeSlide.durationSeconds * 1000).toLong()) +
                                "\n" + (activeSlide.captionSnippet.ifEmpty { "Subtitle" })
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Slide Caption", srt))
                        android.widget.Toast.makeText(context, "Slide SRT copied to clipboard", android.widget.Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Copy SRT Snippet", color = CinemaCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
