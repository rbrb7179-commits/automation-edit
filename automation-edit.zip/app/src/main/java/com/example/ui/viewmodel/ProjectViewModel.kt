package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.SeedData
import com.example.data.model.AspectRatioType
import com.example.data.model.CaptionPosition
import com.example.data.model.CaptionStyle
import com.example.data.model.ColorGradingPreset
import com.example.data.model.FrameRateType
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ResolutionType
import com.example.data.model.SyncMode
import com.example.data.model.VideoCodecType
import com.example.data.repository.ProjectRepository
import com.example.data.media.AudioFileInfo
import com.example.data.media.AudioPlaybackManager
import com.example.data.media.MediaHelper
import com.example.data.media.RealAudioPlayerState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class EditorTab(val title: String, val icon: String) {
    TIMELINE("Timeline", "timeline"),
    MEDIA_ORDER("Slides", "photo_library"),
    SCRIPT_SYNC("Script & Sync", "subtitles"),
    KEN_BURNS("Motion", "animation"),
    COLOR_GRADE("Grade", "palette"),
    AUDIO_SFX("Audio & SFX", "music_note"),
    CAPTIONS("Captions", "closed_caption"),
    EXPORT("Export", "file_upload")
}

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentPositionSec: Float = 0f,
    val activeSlideIndex: Int = 0
)

enum class SyncStep(val title: String, val subtitle: String) {
    AUDIO_TRANSCRIPTION("Speech Transcription & Timestamping", "Extracting sentence-level millisecond cadence from audio"),
    IMAGE_ANALYSIS("Multimodal Visual Recognition", "Analyzing visual features and narrative context"),
    TIMELINE_ALIGNMENT("Timeline Synchronization & Ken Burns", "Constructing non-overlapping zero-gap video clips")
}

sealed class AutoSyncWorkflowState {
    object Idle : AutoSyncWorkflowState()

    data class InProgress(
        val currentStep: SyncStep,
        val stepProgress: Float,
        val stepDetail: String,
        val mode: SyncMode
    ) : AutoSyncWorkflowState()

    data class Completed(
        val mode: SyncMode,
        val slideCount: Int,
        val audioDurationSec: Float,
        val engineStatus: String,
        val pacingNotes: String,
        val updatedSlides: List<MediaSlideEntity>
    ) : AutoSyncWorkflowState()

    data class Error(
        val errorMessage: String,
        val mode: SyncMode,
        val canRetry: Boolean = true
    ) : AutoSyncWorkflowState()
}

class ProjectViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = ProjectRepository(db)

    // Real native audio playback controller
    val audioPlayer = AudioPlaybackManager(application.applicationContext, viewModelScope)
    val realAudioState: StateFlow<RealAudioPlayerState> = audioPlayer.state

    private val _isBatchImporting = MutableStateFlow(false)
    val isBatchImporting = _isBatchImporting.asStateFlow()

    private val _scriptSaveStatus = MutableStateFlow("Saved")
    val scriptSaveStatus = _scriptSaveStatus.asStateFlow()

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId = _selectedProjectId.asStateFlow()

    private val _currentProject = MutableStateFlow<ProjectEntity?>(null)
    val currentProject = _currentProject.asStateFlow()

    private val _currentSlides = MutableStateFlow<List<MediaSlideEntity>>(emptyList())
    val currentSlides = _currentSlides.asStateFlow()

    private val _activeSlide = MutableStateFlow<MediaSlideEntity?>(null)
    val activeSlide = _activeSlide.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState = _playbackState.asStateFlow()

    private val _activeTab = MutableStateFlow(EditorTab.TIMELINE)
    val activeTab = _activeTab.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage = _notificationMessage.asStateFlow()

    private val _autoSyncWorkflow = MutableStateFlow<AutoSyncWorkflowState>(AutoSyncWorkflowState.Idle)
    val autoSyncWorkflow = _autoSyncWorkflow.asStateFlow()

    private var playbackJob: Job? = null
    private var syncJob: Job? = null
    private var lastAttemptedMode: SyncMode = SyncMode.SMART_AI

    init {
        viewModelScope.launch {
            SeedData.populateIfEmpty(db)
            // Automatically select first project if available
            val list = repository.allProjects.firstOrNull()
            if (!list.isNullOrEmpty() && _selectedProjectId.value == null) {
                selectProject(list.first().id)
            }
        }
    }

    fun selectProject(projectId: Long) {
        _selectedProjectId.value = projectId
        pausePlayback()
        audioPlayer.stop()
        _playbackState.value = PlaybackState(isPlaying = false, currentPositionSec = 0f, activeSlideIndex = 0)

        viewModelScope.launch {
            repository.getProject(projectId).collect { proj ->
                _currentProject.value = proj
                if (proj?.voiceAudioUri != null) {
                    audioPlayer.loadAudio(proj.voiceAudioUri)
                }
            }
        }

        viewModelScope.launch {
            repository.getSlides(projectId).collect { slides ->
                _currentSlides.value = slides
                if (slides.isNotEmpty()) {
                    val curIdx = _playbackState.value.activeSlideIndex.coerceIn(0, slides.size - 1)
                    _activeSlide.value = slides[curIdx]
                } else {
                    _activeSlide.value = null
                }
            }
        }
    }

    fun setActiveTab(tab: EditorTab) {
        _activeTab.value = tab
    }

    fun selectSlideIndex(index: Int) {
        val slides = _currentSlides.value
        if (index in slides.indices) {
            var timeAcc = 0f
            for (i in 0 until index) {
                timeAcc += slides[i].durationSeconds
            }
            _activeSlide.value = slides[index]
            _playbackState.value = _playbackState.value.copy(
                activeSlideIndex = index,
                currentPositionSec = timeAcc
            )
        }
    }

    fun togglePlayback() {
        if (_playbackState.value.isPlaying) {
            pausePlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val slides = _currentSlides.value
        if (slides.isEmpty()) return

        val totalDuration = slides.sumOf { it.durationSeconds.toDouble() }.toFloat().coerceAtLeast(1f)
        if (_playbackState.value.currentPositionSec >= totalDuration) {
            _playbackState.value = _playbackState.value.copy(currentPositionSec = 0f, activeSlideIndex = 0)
        }

        _playbackState.value = _playbackState.value.copy(isPlaying = true)
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val stepSec = 0.05f // 50ms update interval for butter-smooth scrubbing
            while (isActive && _playbackState.value.isPlaying) {
                delay(50)
                val newPos = _playbackState.value.currentPositionSec + stepSec
                if (newPos >= totalDuration) {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionSec = totalDuration
                    )
                    break
                }

                // Determine active slide
                var running = 0f
                var slideIdx = 0
                for (i in slides.indices) {
                    val slide = slides[i]
                    if (newPos >= running && newPos < running + slide.durationSeconds) {
                        slideIdx = i
                        break
                    }
                    running += slide.durationSeconds
                    slideIdx = i
                }

                _playbackState.value = _playbackState.value.copy(
                    currentPositionSec = newPos,
                    activeSlideIndex = slideIdx
                )
                if (slideIdx in slides.indices) {
                    _activeSlide.value = slides[slideIdx]
                }
            }
        }
    }

    fun pausePlayback() {
        playbackJob?.cancel()
        _playbackState.value = _playbackState.value.copy(isPlaying = false)
    }

    fun seekTo(seconds: Float) {
        val slides = _currentSlides.value
        val total = slides.sumOf { it.durationSeconds.toDouble() }.toFloat().coerceAtLeast(1f)
        val clamped = seconds.coerceIn(0f, total)

        var running = 0f
        var slideIdx = 0
        for (i in slides.indices) {
            val slide = slides[i]
            if (clamped >= running && clamped < running + slide.durationSeconds) {
                slideIdx = i
                break
            }
            running += slide.durationSeconds
            slideIdx = i
        }

        _playbackState.value = _playbackState.value.copy(
            currentPositionSec = clamped,
            activeSlideIndex = slideIdx
        )
        if (slideIdx in slides.indices) {
            _activeSlide.value = slides[slideIdx]
        }
    }

    fun createProject(
        title: String,
        description: String,
        aspectRatio: AspectRatioType,
        resolution: ResolutionType,
        frameRate: FrameRateType,
        codec: VideoCodecType
    ) {
        viewModelScope.launch {
            val entity = ProjectEntity(
                title = title.ifBlank { "Untitled Documentary" },
                description = description,
                aspectRatio = aspectRatio.name,
                resolution = resolution.name,
                frameRate = frameRate.name,
                codec = codec.name,
                scriptText = "",
                syncMode = SyncMode.SMART_AI.name
            )
            val id = repository.createProject(entity)

            // Add 2 initial slide placeholders so timeline is ready
            repository.addSlide(
                MediaSlideEntity(
                    projectId = id,
                    serialOrder = 1,
                    imageUri = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
                    title = "Opening Shot",
                    durationSeconds = 5.0f,
                    kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                    captionSnippet = "The story begins with an unseen revelation."
                )
            )
            repository.addSlide(
                MediaSlideEntity(
                    projectId = id,
                    serialOrder = 2,
                    imageUri = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80",
                    title = "Second Scene",
                    durationSeconds = 5.0f,
                    kenBurnsMotion = KenBurnsMotion.PAN_LEFT_TO_RIGHT.name,
                    captionSnippet = "Evidence uncovered across the landscape."
                )
            )

            selectProject(id)
            showNotification("Created project: ${entity.title}")
        }
    }

    fun addSlideImage(imageUri: String, title: String) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.addSlide(
                MediaSlideEntity(
                    projectId = projId,
                    serialOrder = 999, // repository auto assigns next
                    imageUri = imageUri,
                    title = title.ifBlank { "Slide #${_currentSlides.value.size + 1}" },
                    durationSeconds = 5.0f,
                    kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                    captionSnippet = ""
                )
            )
            showNotification("Added slide to timeline")
        }
    }

    fun moveSlide(fromIndex: Int, toIndex: Int) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.moveSlide(projId, fromIndex, toIndex)
        }
    }

    fun deleteSlide(slideId: Long) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.deleteSlide(slideId, projId)
            showNotification("Deleted slide from timeline")
        }
    }

    fun updateSlideMotion(slide: MediaSlideEntity, motion: KenBurnsMotion) {
        viewModelScope.launch {
            repository.updateSlide(slide.copy(kenBurnsMotion = motion.name))
        }
    }

    fun updateSlideDuration(slide: MediaSlideEntity, duration: Float) {
        viewModelScope.launch {
            val clamped = duration.coerceIn(1.0f, 60.0f)
            repository.updateSlide(slide.copy(durationSeconds = clamped))
        }
    }

    fun updateSlideCaption(slide: MediaSlideEntity, caption: String) {
        viewModelScope.launch {
            repository.updateSlide(slide.copy(captionSnippet = caption))
        }
    }

    fun updateSlideSoundEffect(slide: MediaSlideEntity, sfxId: String?) {
        viewModelScope.launch {
            repository.updateSlide(slide.copy(soundEffectCue = sfxId))
            showNotification(if (sfxId != null) "Assigned SFX to slide" else "Removed SFX")
        }
    }

    fun addMultipleImages(items: List<Pair<String, String>>) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            _isBatchImporting.value = true
            repository.addMultipleSlides(projId, items)
            delay(200)
            _isBatchImporting.value = false
            showNotification("Added ${items.size} images to sequence")
        }
    }

    fun replaceSlideImage(slideId: Long, newUri: String, newTitle: String? = null) {
        viewModelScope.launch {
            repository.replaceSlideImage(slideId, newUri, newTitle)
            showNotification("Replaced slide image")
        }
    }

    fun swapSlides(indexA: Int, indexB: Int) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.swapSlides(projId, indexA, indexB)
        }
    }

    fun moveSlideToTop(fromIndex: Int) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.moveSlideToTop(projId, fromIndex)
        }
    }

    fun moveSlideToEnd(fromIndex: Int) {
        val projId = _selectedProjectId.value ?: return
        viewModelScope.launch {
            repository.moveSlideToEnd(projId, fromIndex)
        }
    }

    fun updateScript(script: String) {
        updateScriptAutoSave(script)
    }

    fun updateScriptAutoSave(script: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            _scriptSaveStatus.value = "Saving..."
            repository.updateProject(proj.copy(scriptText = script))
            delay(150)
            _scriptSaveStatus.value = "Saved"
        }
    }

    fun importScriptTxt(text: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            _scriptSaveStatus.value = "Importing..."
            repository.updateProject(proj.copy(scriptText = text))
            _scriptSaveStatus.value = "Saved"
            val wordCount = text.split(Regex("\\s+")).count { it.isNotBlank() }
            showNotification("Imported script: $wordCount words")
        }
    }

    fun uploadVoiceAudio(fileName: String, durationSec: Float, uri: String? = null) {
        val proj = _currentProject.value ?: return
        val targetUri = uri ?: "content://audio/$fileName"
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    voiceAudioFileName = fileName,
                    voiceAudioDurationSec = durationSec,
                    voiceAudioUri = targetUri
                )
            )
            audioPlayer.loadAudio(targetUri)
            showNotification("Voice-over audio loaded: $fileName (${durationSec.toInt()}s)")
        }
    }

    fun uploadVoiceAudioDetailed(info: AudioFileInfo) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    voiceAudioFileName = info.fileName,
                    voiceAudioDurationSec = info.durationSec,
                    voiceAudioUri = info.uriString,
                    voiceAudioFileSize = info.fileSizeBytes
                )
            )
            audioPlayer.loadAudio(info.uriString)
            showNotification("Loaded voice-over: ${info.fileName} (${MediaHelper.formatDuration(info.durationSec)})")
        }
    }

    fun removeVoiceAudio() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            audioPlayer.stop()
            repository.updateProject(
                proj.copy(
                    voiceAudioFileName = null,
                    voiceAudioUri = null,
                    voiceAudioFileSize = 0L
                )
            )
            showNotification("Voice-over audio removed")
        }
    }

    fun toggleRealAudio() {
        audioPlayer.togglePlayPause()
    }

    fun seekRealAudio(positionMs: Long) {
        audioPlayer.seekTo(positionMs)
    }

    fun stopRealAudio() {
        audioPlayer.stop()
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
    }

    fun startAutoSync(mode: SyncMode) {
        val proj = _currentProject.value ?: return
        val slides = _currentSlides.value
        if (slides.isEmpty()) {
            showNotification("Please add image slides before running sync")
            return
        }

        lastAttemptedMode = mode
        syncJob?.cancel()

        syncJob = viewModelScope.launch {
            try {
                // Step 1: Voice-Over Transcription & Timestamping
                _autoSyncWorkflow.value = AutoSyncWorkflowState.InProgress(
                    currentStep = SyncStep.AUDIO_TRANSCRIPTION,
                    stepProgress = 0.25f,
                    stepDetail = if (proj.voiceAudioFileName != null) {
                        "Analyzing '${proj.voiceAudioFileName}' waveform & cadence..."
                    } else {
                        "Analyzing script clauses & rhetorical pauses..."
                    },
                    mode = mode
                )

                delay(500)

                // Step 2: Multimodal Visual Recognition
                _autoSyncWorkflow.value = AutoSyncWorkflowState.InProgress(
                    currentStep = SyncStep.IMAGE_ANALYSIS,
                    stepProgress = 0.60f,
                    stepDetail = "Inspecting visual attributes across ${slides.size} slide images...",
                    mode = mode
                )

                delay(500)

                // Step 3: Timeline Synchronization & Ken Burns Generation
                _autoSyncWorkflow.value = AutoSyncWorkflowState.InProgress(
                    currentStep = SyncStep.TIMELINE_ALIGNMENT,
                    stepProgress = 0.85f,
                    stepDetail = if (mode == SyncMode.SEQUENTIAL) {
                        "Aligning sentence durations in sequential upload order (no reordering)..."
                    } else {
                        "Computing semantic scene matches & continuous zero-gap timeline clips..."
                    },
                    mode = mode
                )

                val (updatedSlides, status, pacing) = if (mode == SyncMode.SEQUENTIAL) {
                    val updated = repository.executeSequentialSync(getApplication(), proj.id)
                    Triple(
                        updated,
                        "Sequential Cadence Synchronization (Original order preserved)",
                        "Timeline clips spaced by sentence speaking time with continuous coverage."
                    )
                } else {
                    val (updated, aiResult) = repository.executeSmartAiSync(getApplication(), proj.id)
                    Triple(
                        updated,
                        aiResult.statusMessage,
                        aiResult.overallPacingAnalysis
                    )
                }

                _autoSyncWorkflow.value = AutoSyncWorkflowState.Completed(
                    mode = mode,
                    slideCount = updatedSlides.size,
                    audioDurationSec = proj.voiceAudioDurationSec,
                    engineStatus = status,
                    pacingNotes = pacing,
                    updatedSlides = updatedSlides
                )
                showNotification("Completed ${mode.title}: ${updatedSlides.size} clips synchronized")
            } catch (e: kotlinx.coroutines.CancellationException) {
                _autoSyncWorkflow.value = AutoSyncWorkflowState.Idle
                showNotification("Synchronization canceled")
                throw e
            } catch (e: Exception) {
                _autoSyncWorkflow.value = AutoSyncWorkflowState.Error(
                    errorMessage = e.localizedMessage ?: "Sync processing encountered an issue",
                    mode = mode,
                    canRetry = true
                )
            }
        }
    }

    fun cancelAutoSync() {
        syncJob?.cancel()
        _autoSyncWorkflow.value = AutoSyncWorkflowState.Idle
        showNotification("Canceled synchronization")
    }

    fun retryAutoSync() {
        startAutoSync(lastAttemptedMode)
    }

    fun dismissAutoSync() {
        _autoSyncWorkflow.value = AutoSyncWorkflowState.Idle
    }

    fun manualSwapSceneImages(slideIdA: Long, slideIdB: Long) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.manualSwapSceneImages(proj.id, slideIdA, slideIdB)
            showNotification("Swapped scene visuals while keeping narration cadence")
        }
    }

    fun runSync(mode: SyncMode) {
        startAutoSync(mode)
    }

    fun updateColorGrading(preset: ColorGradingPreset, intensity: Float) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    colorGradingPreset = preset.name,
                    gradingIntensity = intensity
                )
            )
        }
    }

    fun updateAudioSettings(bgmPresetId: String, bgmVolume: Float, voiceVolume: Float, ducking: Boolean) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    bgmPresetId = bgmPresetId,
                    bgmVolume = bgmVolume,
                    voiceVolume = voiceVolume,
                    duckingEnabled = ducking
                )
            )
            showNotification("Audio mix updated")
        }
    }

    fun updateCaptionSettings(enabled: Boolean, style: CaptionStyle, position: CaptionPosition) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    autoCaptionsEnabled = enabled,
                    captionStyle = style.name,
                    captionPosition = position.name
                )
            )
            showNotification("Caption settings saved")
        }
    }

    fun updateExportSettings(
        aspectRatio: AspectRatioType,
        resolution: ResolutionType,
        frameRate: FrameRateType,
        codec: VideoCodecType
    ) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(
                proj.copy(
                    aspectRatio = aspectRatio.name,
                    resolution = resolution.name,
                    frameRate = frameRate.name,
                    codec = codec.name
                )
            )
            showNotification("Export format updated")
        }
    }

    fun deleteCurrentProject() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.deleteProject(proj.id)
            _selectedProjectId.value = null
            _currentProject.value = null
            _currentSlides.value = emptyList()
            showNotification("Project deleted")
        }
    }

    fun showNotification(message: String) {
        _notificationMessage.value = message
    }

    fun clearNotification() {
        _notificationMessage.value = null
    }
}
