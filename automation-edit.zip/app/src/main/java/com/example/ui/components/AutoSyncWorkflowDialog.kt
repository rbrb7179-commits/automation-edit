package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.media.MediaHelper
import com.example.data.model.MediaSlideEntity
import com.example.data.model.SyncMode
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCoral
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant
import com.example.ui.viewmodel.AutoSyncWorkflowState
import com.example.ui.viewmodel.SyncStep

@Composable
fun AutoSyncWorkflowDialog(
    workflowState: AutoSyncWorkflowState,
    allSlides: List<MediaSlideEntity>,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
    onSwapScenes: (Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (workflowState is AutoSyncWorkflowState.Idle) return

    var swapSourceSlide by remember { mutableStateOf<MediaSlideEntity?>(null) }

    Dialog(
        onDismissRequest = {
            if (workflowState !is AutoSyncWorkflowState.InProgress) {
                onDismiss()
            }
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, CinemaBorder, RoundedCornerShape(14.dp)),
            color = CinemaBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = CinemaCyan.copy(alpha = 0.2f),
                            shape = CircleShape,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = CinemaCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "AI Auto-Sync Engine",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Voice-to-Image Narrative Timeline Alignment",
                                color = CinemaCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (workflowState !is AutoSyncWorkflowState.InProgress) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("btn_close_sync_dialog")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                when (workflowState) {
                    is AutoSyncWorkflowState.InProgress -> {
                        SyncInProgressContent(
                            state = workflowState,
                            onCancel = onCancel
                        )
                    }
                    is AutoSyncWorkflowState.Completed -> {
                        SyncCompletedContent(
                            state = workflowState,
                            allSlides = allSlides,
                            swapSourceSlide = swapSourceSlide,
                            onSelectSwapSource = { swapSourceSlide = it },
                            onSwapWith = { target ->
                                swapSourceSlide?.let { src ->
                                    onSwapScenes(src.id, target.id)
                                    swapSourceSlide = null
                                }
                            },
                            onDismiss = onDismiss
                        )
                    }
                    is AutoSyncWorkflowState.Error -> {
                        SyncErrorContent(
                            state = workflowState,
                            onRetry = onRetry,
                            onCancel = onDismiss
                        )
                    }
                    else -> Unit
                }
            }
        }
    }
}

@Composable
private fun SyncInProgressContent(
    state: AutoSyncWorkflowState.InProgress,
    onCancel: () -> Unit
) {
    val animatedProgress by animateFloatAsState(targetValue = state.stepProgress, label = "sync_progress")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                color = CinemaSurfaceElevated,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan.copy(alpha = 0.5f))
            ) {
                Text(
                    text = if (state.mode == SyncMode.SEQUENTIAL) "SEQUENTIAL SYNC" else "SMART AI MULTIMODAL SYNC",
                    color = CinemaCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            CircularProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier.size(72.dp),
                color = CinemaCyan,
                strokeWidth = 4.dp,
                trackColor = CinemaSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "${(animatedProgress * 100).toInt()}%",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )

            Text(
                text = state.currentStep.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )

            Text(
                text = state.stepDetail,
                color = Color.LightGray,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Step Progress Checklist
            Card(
                colors = CardDefaults.cardColors(containerColor = CinemaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SyncStepItem(
                        step = SyncStep.AUDIO_TRANSCRIPTION,
                        currentStep = state.currentStep,
                        stepNumber = 1
                    )
                    SyncStepItem(
                        step = SyncStep.IMAGE_ANALYSIS,
                        currentStep = state.currentStep,
                        stepNumber = 2
                    )
                    SyncStepItem(
                        step = SyncStep.TIMELINE_ALIGNMENT,
                        currentStep = state.currentStep,
                        stepNumber = 3
                    )
                }
            }
        }

        // Cancel Button
        OutlinedButton(
            onClick = onCancel,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaCoral),
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCoral),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth(0.6f)
                .testTag("btn_cancel_sync")
        ) {
            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Cancel Synchronization", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SyncStepItem(
    step: SyncStep,
    currentStep: SyncStep,
    stepNumber: Int
) {
    val isDone = step.ordinal < currentStep.ordinal
    val isActive = step == currentStep

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            color = when {
                isDone -> CinemaEmerald
                isActive -> CinemaCyan
                else -> CinemaSurfaceVariant
            },
            shape = CircleShape,
            modifier = Modifier.size(24.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (isDone) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                } else {
                    Text(
                        text = "$stepNumber",
                        color = if (isActive) Color.Black else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = step.title,
                color = if (isActive || isDone) Color.White else Color.Gray,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                fontSize = 11.sp
            )
            Text(
                text = step.subtitle,
                color = Color.Gray,
                fontSize = 9.sp
            )
        }

        if (isActive) {
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                color = CinemaCyan,
                strokeWidth = 2.dp
            )
        }
    }
}

@Composable
private fun SyncCompletedContent(
    state: AutoSyncWorkflowState.Completed,
    allSlides: List<MediaSlideEntity>,
    swapSourceSlide: MediaSlideEntity?,
    onSelectSwapSource: (MediaSlideEntity?) -> Unit,
    onSwapWith: (MediaSlideEntity) -> Unit,
    onDismiss: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Summary Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CinemaSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaEmerald.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CinemaEmerald, modifier = Modifier.size(18.dp))
                        Text("Timeline Synchronized", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Surface(
                        color = CinemaEmerald.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "${state.slideCount} CLIPS • ${state.audioDurationSec.toInt()}s",
                            color = CinemaEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = state.engineStatus,
                    color = CinemaCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = state.pacingNotes,
                    color = Color.LightGray,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Instruction / Swap banner
        if (swapSourceSlide != null) {
            Surface(
                color = CinemaAmberGold.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaAmberGold),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Tap any scene below to swap visuals with Scene #${swapSourceSlide.serialOrder}",
                        color = CinemaAmberGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                    IconButton(onClick = { onSelectSwapSource(null) }, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel swap", tint = CinemaAmberGold, modifier = Modifier.size(14.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Text(
            text = "Synchronized Scene Clips (${allSlides.size}) — Zero Gaps Guaranteed",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Clips List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(allSlides) { index, slide ->
                val isSelectedForSwap = swapSourceSlide?.id == slide.id

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelectedForSwap) CinemaSurfaceElevated else CinemaSurface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelectedForSwap) CinemaAmberGold else CinemaBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (swapSourceSlide == null) {
                                onSelectSwapSource(slide)
                            } else if (swapSourceSlide.id != slide.id) {
                                onSwapWith(slide)
                            }
                        }
                        .testTag("synced_clip_item_$index")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Thumbnail
                        Box(
                            modifier = Modifier
                                .size(50.dp, 36.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black)
                        ) {
                            AsyncImage(
                                model = slide.imageUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                color = Color.Black.copy(alpha = 0.75f),
                                modifier = Modifier.align(Alignment.BottomStart)
                            ) {
                                Text(
                                    text = "#${slide.serialOrder}",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 2.dp)
                                )
                            }
                        }

                        // Info
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "${MediaHelper.formatDuration(slide.startTimeSec)} → ${MediaHelper.formatDuration(slide.endTimeSec)} (${slide.durationSeconds}s)",
                                    color = CinemaCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                slide.syncConfidenceScore?.let { score ->
                                    val percent = (score * 100).toInt()
                                    Surface(
                                        color = if (percent >= 85) CinemaEmerald.copy(alpha = 0.2f) else CinemaAmberGold.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(3.dp)
                                    ) {
                                        Text(
                                            text = "$percent% MATCH",
                                            color = if (percent >= 85) CinemaEmerald else CinemaAmberGold,
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = slide.captionSnippet.ifBlank { slide.title },
                                color = Color.White,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            slide.matchReason?.let { reason ->
                                Text(
                                    text = reason,
                                    color = Color.Gray,
                                    fontSize = 8.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Swap Button
                        IconButton(
                            onClick = {
                                if (swapSourceSlide == null) {
                                    onSelectSwapSource(slide)
                                } else if (swapSourceSlide.id != slide.id) {
                                    onSwapWith(slide)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.SwapHoriz,
                                contentDescription = "Swap visual",
                                tint = if (isSelectedForSwap) CinemaAmberGold else CinemaCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(
                containerColor = CinemaAmberGold,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_apply_sync_confirm")
        ) {
            Text("Apply Timeline & Return to Editor", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SyncErrorContent(
    state: AutoSyncWorkflowState.Error,
    onRetry: () -> Unit,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.ErrorOutline,
            contentDescription = null,
            tint = CinemaCoral,
            modifier = Modifier.size(48.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Synchronization Notice",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = state.errorMessage,
            color = Color.LightGray,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onCancel,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Dismiss", fontSize = 12.sp)
            }

            if (state.canRetry) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CinemaCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Retry Sync", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
