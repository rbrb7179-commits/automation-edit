package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioType
import com.example.data.model.FrameRateType
import com.example.data.model.ResolutionType
import com.example.data.model.VideoCodecType
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaCoral
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun NewProjectScreen(
    onNavigateBack: () -> Unit,
    onCreateProject: (
        title: String,
        description: String,
        aspectRatio: AspectRatioType,
        resolution: ResolutionType,
        frameRate: FrameRateType,
        codec: VideoCodecType
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedAspect by remember { mutableStateOf(AspectRatioType.LANDSCAPE_16_9) }
    var selectedRes by remember { mutableStateOf(ResolutionType.RES_1080P) }
    var selectedFps by remember { mutableStateOf(FrameRateType.FPS_24) }
    var selectedCodec by remember { mutableStateOf(VideoCodecType.CODEC_H264) }

    Scaffold(
        containerColor = CinemaBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CinemaBackground)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("new_project_back_btn")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text("Create New Documentary", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Project Title
            Text("Documentary Title", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("e.g. The Untold Secrets of the Deep Sahara", color = Color.Gray, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CinemaSurface,
                    unfocusedContainerColor = CinemaSurface,
                    focusedBorderColor = CinemaAmberGold,
                    unfocusedBorderColor = CinemaBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.LightGray
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_project_title_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Description
            Text("Synopsis / Logline (Optional)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                placeholder = { Text("Brief one-line overview for the documentary cut", color = Color.Gray, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CinemaSurface,
                    unfocusedContainerColor = CinemaSurface,
                    focusedBorderColor = CinemaAmberGold,
                    unfocusedBorderColor = CinemaBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.LightGray
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .testTag("new_project_desc_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Aspect Ratio (Shorts 9:16 vs Long 16:9)
            Text("Format & Aspect Ratio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AspectRatioType.values().forEach { aspect ->
                    val isSelected = aspect == selectedAspect
                    Surface(
                        color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) CinemaAmberGold else CinemaBorder
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedAspect = aspect }
                            .testTag("new_aspect_${aspect.name.lowercase()}")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = aspect.label,
                                color = if (isSelected) CinemaAmberGold else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (aspect == AspectRatioType.SHORTS_9_16) "Shorts / Reels" else "YouTube Long Form",
                                color = Color.Gray,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Resolution
            Text("Canvas Resolution", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ResolutionType.values().forEach { res ->
                    val isSelected = res == selectedRes
                    Surface(
                        color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) CinemaCyan else CinemaBorder
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedRes = res }
                            .testTag("new_res_${res.name.lowercase()}")
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = res.label.substringBefore(" ("),
                                color = if (isSelected) CinemaCyan else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = if (res == ResolutionType.RES_4K) "Cinematic UHD" else "Standard FHD",
                                color = Color.Gray,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Frame Rate
            Text("Frame Rate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FrameRateType.values().forEach { fps ->
                    val isSelected = fps == selectedFps
                    Surface(
                        color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) CinemaAmberGold else CinemaBorder
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedFps = fps }
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${fps.fps} fps",
                                color = if (isSelected) CinemaAmberGold else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = if (fps == FrameRateType.FPS_24) "Cinema" else if (fps == FrameRateType.FPS_30) "Web" else "Smooth",
                                color = Color.Gray,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Submit Button
            Button(
                onClick = {
                    onCreateProject(
                        title.ifBlank { "Untitled Documentary" },
                        description,
                        selectedAspect,
                        selectedRes,
                        selectedFps,
                        selectedCodec
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("create_project_confirm_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CinemaAmberGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Create, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Project & Launch Timeline", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
