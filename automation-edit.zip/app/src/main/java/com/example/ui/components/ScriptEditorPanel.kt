package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.media.MediaHelper
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SyncMode
import com.example.integration.SpeechRecognitionBridgeImpl
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCoral
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ScriptEditorPanel(
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    saveStatus: String,
    onScriptChanged: (String) -> Unit,
    onImportTxt: (String) -> Unit,
    onRunSync: (SyncMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var scriptText by remember(project.scriptText) { mutableStateOf(project.scriptText) }
    var isTranscribing by remember { mutableStateOf(false) }
    var transcriptionSuccessMsg by remember { mutableStateOf<String?>(null) }

    // SAF Document Picker for .TXT files
    val txtFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val content = MediaHelper.readTextFromUri(context, uri)
            if (!content.isNullOrBlank()) {
                scriptText = content
                onImportTxt(content)
            }
        }
    }

    val wordCount = remember(scriptText) {
        if (scriptText.isBlank()) 0
        else scriptText.split(Regex("\\s+")).count { it.isNotBlank() }
    }

    val charCount = remember(scriptText) { scriptText.length }

    val sentenceCount = remember(scriptText) {
        if (scriptText.isBlank()) 0
        else scriptText.split(Regex("(?<=[.!?])\\s+")).count { it.isNotBlank() }
    }

    // Natural documentary reading speed: ~130 words per minute = 2.16 words/sec
    val estSpeechDurationSec = remember(wordCount) {
        (wordCount / 2.16f).toInt()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // Header: Title, Stats & Auto-Save Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Documentary Script Editor",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Surface(
                        color = if (saveStatus == "Saving...") CinemaAmberGold.copy(alpha = 0.2f) else CinemaEmerald.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (saveStatus == "Saving...") "● SAVING..." else "● AUTO-SAVED",
                            color = if (saveStatus == "Saving...") CinemaAmberGold else CinemaEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "$wordCount words • $sentenceCount sentences • $charCount chars (~${MediaHelper.formatDuration(estSpeechDurationSec.toFloat())})",
                    color = CinemaCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // TXT File Import & Helper Actions
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(
                    onClick = { txtFilePicker.launch(arrayOf("text/plain", "text/*")) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaAmberGold),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CinemaAmberGold),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("import_txt_btn")
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Import .TXT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                if (scriptText.isNotBlank()) {
                    IconButton(
                        onClick = {
                            scriptText = ""
                            onScriptChanged("")
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear script", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Professional Multiline Editor
        OutlinedTextField(
            value = scriptText,
            onValueChange = {
                scriptText = it
                onScriptChanged(it)
            },
            placeholder = {
                Text(
                    text = "Type or paste full documentary script here...\n\nExample:\nAcross the uncharted depths of the Pacific, ancient hydrothermal vents support thriving alien ecosystems.\nEach punctuation pause (. ! ?) will automatically align visual slides when synchronizing.",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CinemaBackground,
                unfocusedContainerColor = CinemaBackground,
                focusedBorderColor = CinemaAmberGold,
                unfocusedBorderColor = CinemaBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.LightGray
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .testTag("script_editor_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Future-Ready Speech Transcription Interface
        Card(
            colors = CardDefaults.cardColors(containerColor = CinemaSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = CinemaCyan, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Speech Recognition & AI Transcription Pipeline",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        color = CinemaSurfaceVariant,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "GEMINI / WHISPER HOOK",
                            color = CinemaCyan,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (project.voiceAudioFileName != null) {
                        "Voice-over file '${project.voiceAudioFileName}' is ready for automated word-level speech alignment."
                    } else {
                        "Upload a voice-over file above to enable automated transcription and millisecond speech-to-slide sync."
                    },
                    color = Color.LightGray,
                    fontSize = 10.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            if (!isTranscribing) {
                                isTranscribing = true
                                transcriptionSuccessMsg = null
                                scope.launch {
                                    try {
                                        val bridge = SpeechRecognitionBridgeImpl()
                                        val alignment = bridge.alignVoiceover(
                                            context = context,
                                            audioUriString = project.voiceAudioUri,
                                            referenceScript = scriptText
                                        )
                                        isTranscribing = false
                                        val totalSec = alignment.totalDurationMs / 1000f
                                        transcriptionSuccessMsg = "Aligned ${alignment.sentences.size} sentences & ${alignment.words.size} words across ${MediaHelper.formatDuration(totalSec)} using ${alignment.engineUsed}."
                                    } catch (e: Exception) {
                                        isTranscribing = false
                                        transcriptionSuccessMsg = "Audio analysis notice: ${e.localizedMessage}"
                                    }
                                }
                            }
                        },
                        enabled = !isTranscribing && project.voiceAudioFileName != null,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("btn_transcribe_audio")
                    ) {
                        if (isTranscribing) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Analyzing audio cadence...", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Transcribe Voice-Over", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Sample Script Helper
                    OutlinedButton(
                        onClick = {
                            val sample = "More than eighty percent of our planet's oceans remain completely unmapped.\nBeneath the twilight zone lies a world under crushing hydrostatic pressure.\nHere, hydrothermal chimneys spew superheated minerals into the pitch black abyss.\nIn this extreme frontier, bizarre bioluminescent creatures illuminate the dark ocean floor."
                            scriptText = sample
                            onScriptChanged(sample)
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.FormatQuote, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Insert Sample Script", fontSize = 10.sp)
                    }
                }

                if (transcriptionSuccessMsg != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CinemaEmerald, modifier = Modifier.size(14.dp))
                        Text(transcriptionSuccessMsg!!, color = CinemaEmerald, fontSize = 10.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Automatic Synchronization Triggers
        Text(
            text = "Timeline Slide Synchronization",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
        Text(
            text = "Re-align ${slides.size} image slides against the script sentences and voice duration",
            color = Color.Gray,
            fontSize = 10.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = if (project.syncMode == SyncMode.SEQUENTIAL.name) CinemaSurfaceElevated else CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (project.syncMode == SyncMode.SEQUENTIAL.name) CinemaAmberGold else CinemaBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onRunSync(SyncMode.SEQUENTIAL) }
                    .testTag("sync_sequential_action")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Sync, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(14.dp))
                        Text("Sequential Sync", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text(
                        text = "Even pacing (${if (slides.isNotEmpty()) (project.voiceAudioDurationSec / slides.size).toInt() else 5}s each).",
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                }
            }

            Surface(
                color = if (project.syncMode == SyncMode.SMART_AI.name) CinemaSurfaceElevated else CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (project.syncMode == SyncMode.SMART_AI.name) CinemaCyan else CinemaBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onRunSync(SyncMode.SMART_AI) }
                    .testTag("sync_smart_ai_action")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CinemaCyan, modifier = Modifier.size(14.dp))
                        Text("Smart AI Sync", color = CinemaCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text(
                        text = "Sentence clauses & pause weight alignment.",
                        color = Color.LightGray,
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}
