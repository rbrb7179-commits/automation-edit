package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Charcoal & Obsidian Palette
val CinemaBackground = Color(0xFF0A0D14)
val CinemaSurface = Color(0xFF121722)
val CinemaSurfaceVariant = Color(0xFF1B2333)
val CinemaSurfaceElevated = Color(0xFF242E42)
val CinemaBorder = Color(0xFF2E3A52)

// Accent Colors
val CinemaAmberGold = Color(0xFFF59E0B)
val CinemaAmberLight = Color(0xFFFCD34D)
val CinemaCyan = Color(0xFF38BDF8)
val CinemaCyanGlow = Color(0xFF0284C7)
val CinemaCoral = Color(0xFFF43F5E)
val CinemaEmerald = Color(0xFF10B981)
val CinemaViolet = Color(0xFF8B5CF6)

// Text & Content Colors
val CinemaTextPrimary = Color(0xFFF8FAFC)
val CinemaTextSecondary = Color(0xFF94A3B8)
val CinemaTextTertiary = Color(0xFF64748B)

// Timeline Specific Colors
val TrackVideoColor = Color(0xFF1E3A8A)
val TrackVideoBorder = Color(0xFF3B82F6)
val TrackAudioColor = Color(0xFF065F46)
val TrackAudioBorder = Color(0xFF10B981)
val TrackSfxColor = Color(0xFF581C87)
val TrackSfxBorder = Color(0xFFA855F7)
val TrackCaptionColor = Color(0xFF78350F)
val TrackCaptionBorder = Color(0xFFF59E0B)
val PlayheadColor = Color(0xFFEF4444)
