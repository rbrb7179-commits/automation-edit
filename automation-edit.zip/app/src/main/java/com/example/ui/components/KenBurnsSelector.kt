package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KenBurnsSelector(
    activeSlide: MediaSlideEntity?,
    onMotionChanged: (KenBurnsMotion) -> Unit,
    onDurationChanged: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    if (activeSlide == null) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Select a slide in the timeline to configure camera motion", color = Color.Gray, fontSize = 13.sp)
        }
        return
    }

    val currentMotion = runCatching {
        KenBurnsMotion.valueOf(activeSlide.kenBurnsMotion)
    }.getOrDefault(KenBurnsMotion.SLOW_ZOOM_IN)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Ken Burns Documentary Motion",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Cinematic camera path for Slide #${activeSlide.serialOrder}",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Surface(
                color = CinemaAmberGold.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaAmberGold),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "${activeSlide.durationSeconds}s DURATION",
                    color = CinemaAmberGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Slide duration slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Duration:", color = Color.LightGray, fontSize = 11.sp)
            Slider(
                value = activeSlide.durationSeconds,
                onValueChange = { onDurationChanged((it * 2).toInt() / 2f) },
                valueRange = 2f..15f,
                steps = 25,
                colors = SliderDefaults.colors(
                    thumbColor = CinemaAmberGold,
                    activeTrackColor = CinemaAmberGold,
                    inactiveTrackColor = CinemaBorder
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ken_burns_duration_slider")
            )
            Text(
                text = "${activeSlide.durationSeconds}s",
                color = CinemaCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.width(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Grid of Ken Burns motions
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            KenBurnsMotion.values().forEach { motion ->
                val isSelected = motion == currentMotion
                val icon: ImageVector = when (motion) {
                    KenBurnsMotion.SLOW_ZOOM_IN -> Icons.Default.ZoomIn
                    KenBurnsMotion.SLOW_ZOOM_OUT -> Icons.Default.ZoomOut
                    KenBurnsMotion.PAN_LEFT_TO_RIGHT -> Icons.Default.ArrowForward
                    KenBurnsMotion.PAN_RIGHT_TO_LEFT -> Icons.Default.ArrowBack
                    KenBurnsMotion.DRAMATIC_PUSH -> Icons.Default.Speed
                    KenBurnsMotion.STATIC_LOCKED -> Icons.Default.CropFree
                }

                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaCyan else CinemaBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onMotionChanged(motion) }
                        .testTag("motion_preset_${motion.name.lowercase()}")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = motion.label,
                            tint = if (isSelected) CinemaAmberGold else Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = motion.label,
                            color = if (isSelected) Color.White else Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
