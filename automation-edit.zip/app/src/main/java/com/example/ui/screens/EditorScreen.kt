package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.ui.components.AddMediaDialog
import com.example.ui.components.AudioControlPanel
import com.example.ui.components.CaptionsPanel
import com.example.ui.components.ColorGradingSelector
import androidx.compose.material.icons.filled.AutoAwesome
import com.example.ui.components.AutoSyncWorkflowDialog
import com.example.ui.components.ExportSettingsDialog
import com.example.ui.components.KenBurnsSelector
import com.example.ui.components.MediaSequenceGrid
import com.example.ui.components.MultiTrackTimeline
import com.example.ui.components.RealVoiceOverPlayer
import com.example.ui.components.ScriptEditorPanel
import com.example.ui.components.VideoPreviewCanvas
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant
import com.example.ui.viewmodel.EditorTab
import com.example.ui.viewmodel.PlaybackState
import com.example.ui.viewmodel.ProjectViewModel

@Composable
fun EditorScreen(
    viewModel: ProjectViewModel,
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    activeSlide: MediaSlideEntity?,
    playbackState: PlaybackState,
    activeTab: EditorTab,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    var showAddMediaDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Observe state from ViewModel
    val notification by viewModel.notificationMessage.collectAsStateWithLifecycle()
    val realAudioState by viewModel.realAudioState.collectAsStateWithLifecycle()
    val isBatchImporting by viewModel.isBatchImporting.collectAsStateWithLifecycle()
    val scriptSaveStatus by viewModel.scriptSaveStatus.collectAsStateWithLifecycle()
    val autoSyncWorkflow by viewModel.autoSyncWorkflow.collectAsStateWithLifecycle()

    LaunchedEffect(notification) {
        notification?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearNotification()
        }
    }

    Scaffold(
        containerColor = CinemaBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            // Editor Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CinemaBackground)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("editor_back_btn")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Dashboard", tint = Color.White)
                    }

                    Column {
                        Text(
                            text = project.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${slides.size} Slides • ${project.resolution.removePrefix("RES_")} • ${project.aspectRatio.replace("_", " ")}",
                            color = CinemaCyan,
                            fontSize = 9.sp
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Auto-Sync Button
                    Button(
                        onClick = { viewModel.startAutoSync(com.example.data.model.SyncMode.SMART_AI) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("topbar_auto_sync_btn")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Auto-Sync", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Add Media Button
                    OutlinedButton(
                        onClick = { showAddMediaDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaAmberGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CinemaAmberGold),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("topbar_add_media_btn")
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Media", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Export Button
                    Button(
                        onClick = { showExportDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaAmberGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("topbar_export_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Professional Video Preview Canvas
            VideoPreviewCanvas(
                project = project,
                slides = slides,
                activeSlide = activeSlide,
                currentPositionSec = playbackState.currentPositionSec,
                isPlaying = playbackState.isPlaying,
                onTogglePlay = { viewModel.togglePlayback() }
            )

            // 2. Multi-Track Timeline
            MultiTrackTimeline(
                project = project,
                slides = slides,
                activeSlide = activeSlide,
                currentPositionSec = playbackState.currentPositionSec,
                isPlaying = playbackState.isPlaying,
                onTogglePlay = { viewModel.togglePlayback() },
                onSeekTo = { viewModel.seekTo(it) },
                onSelectSlide = { viewModel.selectSlideIndex(it) },
                onMoveSlideLeft = { viewModel.moveSlide(it, it - 1) },
                onMoveSlideRight = { viewModel.moveSlide(it, it + 1) },
                onDeleteSlide = { viewModel.deleteSlide(it) }
            )

            // 3. Tab Bar for Editor Tool Panels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CinemaSurfaceElevated)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                EditorTabItem(
                    title = "Slides (${slides.size})",
                    icon = Icons.Default.PhotoLibrary,
                    isSelected = activeTab == EditorTab.MEDIA_ORDER,
                    onClick = { viewModel.setActiveTab(EditorTab.MEDIA_ORDER) },
                    tag = "tab_media_slides"
                )
                EditorTabItem(
                    title = "Script & Voice",
                    icon = Icons.Default.Subtitles,
                    isSelected = activeTab == EditorTab.SCRIPT_SYNC,
                    onClick = { viewModel.setActiveTab(EditorTab.SCRIPT_SYNC) },
                    tag = "tab_script_sync"
                )
                EditorTabItem(
                    title = "Motion",
                    icon = Icons.Default.Animation,
                    isSelected = activeTab == EditorTab.KEN_BURNS,
                    onClick = { viewModel.setActiveTab(EditorTab.KEN_BURNS) },
                    tag = "tab_ken_burns"
                )
                EditorTabItem(
                    title = "Color Grade",
                    icon = Icons.Default.Palette,
                    isSelected = activeTab == EditorTab.COLOR_GRADE,
                    onClick = { viewModel.setActiveTab(EditorTab.COLOR_GRADE) },
                    tag = "tab_color_grade"
                )
                EditorTabItem(
                    title = "Audio & SFX",
                    icon = Icons.Default.Audiotrack,
                    isSelected = activeTab == EditorTab.AUDIO_SFX,
                    onClick = { viewModel.setActiveTab(EditorTab.AUDIO_SFX) },
                    tag = "tab_audio_sfx"
                )
                EditorTabItem(
                    title = "Captions",
                    icon = Icons.Default.ClosedCaption,
                    isSelected = activeTab == EditorTab.CAPTIONS,
                    onClick = { viewModel.setActiveTab(EditorTab.CAPTIONS) },
                    tag = "tab_captions"
                )
            }

            // 4. Active Tool Panel View
            Surface(
                color = CinemaSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder))
            ) {
                when (activeTab) {
                    EditorTab.MEDIA_ORDER -> {
                        MediaSequenceGrid(
                            slides = slides,
                            activeSlideId = activeSlide?.id,
                            isUploading = isBatchImporting,
                            onSelectSlide = { viewModel.selectSlideIndex(it) },
                            onAddImages = { list -> viewModel.addMultipleImages(list) },
                            onReplaceImage = { slideId, newUri, newTitle -> viewModel.replaceSlideImage(slideId, newUri, newTitle) },
                            onDeleteSlide = { slideId -> viewModel.deleteSlide(slideId) },
                            onMoveSlide = { from, to -> viewModel.moveSlide(from, to) },
                            onMoveToTop = { from -> viewModel.moveSlideToTop(from) },
                            onMoveToEnd = { from -> viewModel.moveSlideToEnd(from) }
                        )
                    }
                    EditorTab.SCRIPT_SYNC -> {
                        Column {
                            RealVoiceOverPlayer(
                                project = project,
                                audioPlayerState = realAudioState,
                                onPlayPause = { viewModel.toggleRealAudio() },
                                onSeek = { viewModel.seekRealAudio(it) },
                                onStop = { viewModel.stopRealAudio() },
                                onUploadAudio = { info -> viewModel.uploadVoiceAudioDetailed(info) },
                                onRemoveAudio = { viewModel.removeVoiceAudio() }
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            ScriptEditorPanel(
                                project = project,
                                slides = slides,
                                saveStatus = scriptSaveStatus,
                                onScriptChanged = { viewModel.updateScriptAutoSave(it) },
                                onImportTxt = { viewModel.importScriptTxt(it) },
                                onRunSync = { mode -> viewModel.runSync(mode) }
                            )
                        }
                    }
                    EditorTab.KEN_BURNS, EditorTab.TIMELINE -> {
                        KenBurnsSelector(
                            activeSlide = activeSlide,
                            onMotionChanged = { motion ->
                                activeSlide?.let { viewModel.updateSlideMotion(it, motion) }
                            },
                            onDurationChanged = { dur ->
                                activeSlide?.let { viewModel.updateSlideDuration(it, dur) }
                            }
                        )
                    }
                    EditorTab.COLOR_GRADE -> {
                        ColorGradingSelector(
                            project = project,
                            onColorGradingChanged = { preset, intensity ->
                                viewModel.updateColorGrading(preset, intensity)
                            }
                        )
                    }
                    EditorTab.AUDIO_SFX -> {
                        AudioControlPanel(
                            project = project,
                            activeSlide = activeSlide,
                            onAudioSettingsChanged = { bgm, bgmVol, voiceVol, ducking ->
                                viewModel.updateAudioSettings(bgm, bgmVol, voiceVol, ducking)
                            },
                            onSlideSfxChanged = { sfxId ->
                                activeSlide?.let { viewModel.updateSlideSoundEffect(it, sfxId) }
                            }
                        )
                    }
                    EditorTab.CAPTIONS -> {
                        CaptionsPanel(
                            project = project,
                            activeSlide = activeSlide,
                            onCaptionSettingsChanged = { enabled, style, pos ->
                                viewModel.updateCaptionSettings(enabled, style, pos)
                            },
                            onSlideCaptionChanged = { text ->
                                activeSlide?.let { viewModel.updateSlideCaption(it, text) }
                            }
                        )
                    }
                    EditorTab.EXPORT -> {
                        LaunchedEffect(Unit) { showExportDialog = true }
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }

        // Add Media Modal
        if (showAddMediaDialog) {
            AddMediaDialog(
                existingCount = slides.size,
                onAddImages = { list -> viewModel.addMultipleImages(list) },
                onDismiss = { showAddMediaDialog = false }
            )
        }

        // Export Settings Modal
        if (showExportDialog) {
            ExportSettingsDialog(
                project = project,
                slides = slides,
                onDismiss = { showExportDialog = false },
                onSaveExportSettings = { aspect, res, fps, codec ->
                    viewModel.updateExportSettings(aspect, res, fps, codec)
                }
            )
        }

        // AI Auto-Sync Workflow Modal
        AutoSyncWorkflowDialog(
            workflowState = autoSyncWorkflow,
            allSlides = slides,
            onCancel = { viewModel.cancelAutoSync() },
            onRetry = { viewModel.retryAutoSync() },
            onDismiss = { viewModel.dismissAutoSync() },
            onSwapScenes = { idA, idB -> viewModel.manualSwapSceneImages(idA, idB) }
        )
    }
}

@Composable
private fun EditorTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        color = if (isSelected) CinemaAmberGold else CinemaSurfaceVariant,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.Black else Color.LightGray,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = title,
                color = if (isSelected) Color.Black else Color.White,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
