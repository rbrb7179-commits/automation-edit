package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColorGradingPreset
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun ColorGradingSelector(
    project: ProjectEntity,
    onColorGradingChanged: (ColorGradingPreset, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPreset = runCatching {
        ColorGradingPreset.valueOf(project.colorGradingPreset)
    }.getOrDefault(ColorGradingPreset.WARM_DOCUMENTARY)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Cinematic Color Grading",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Tone curves, film contrast & archival tinting",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Surface(
                color = CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = currentPreset.title.uppercase(),
                    color = CinemaCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Intensity slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Intensity:", color = Color.LightGray, fontSize = 11.sp)
            Slider(
                value = project.gradingIntensity,
                onValueChange = { onColorGradingChanged(currentPreset, it) },
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = CinemaAmberGold,
                    activeTrackColor = CinemaAmberGold,
                    inactiveTrackColor = CinemaBorder
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("color_intensity_slider")
            )
            Text(
                text = "${(project.gradingIntensity * 100).toInt()}%",
                color = CinemaAmberGold,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.width(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal scrolling presets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ColorGradingPreset.values().forEach { preset ->
                val isSelected = preset == currentPreset

                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaAmberGold else CinemaBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .width(135.dp)
                        .clickable { onColorGradingChanged(preset, project.gradingIntensity) }
                        .testTag("color_preset_${preset.name.lowercase()}")
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .background(Color(preset.primaryToneHex), CircleShape)
                                    .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                            )
                            Text(
                                text = preset.title,
                                color = if (isSelected) Color.White else Color.LightGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = preset.description,
                            color = Color.Gray,
                            fontSize = 9.sp,
                            lineHeight = 12.sp,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}
