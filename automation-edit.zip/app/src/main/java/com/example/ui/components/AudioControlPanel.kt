package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioLibrary
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun AudioControlPanel(
    project: ProjectEntity,
    activeSlide: MediaSlideEntity?,
    onAudioSettingsChanged: (bgmPresetId: String, bgmVolume: Float, voiceVolume: Float, ducking: Boolean) -> Unit,
    onSlideSfxChanged: (sfxId: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // BGM Selection Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Background Music (BGM)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Cinematic documentary score selection", color = Color.Gray, fontSize = 10.sp)
            }
            Surface(
                color = CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "${(project.bgmVolume * 100).toInt()}% BGM VOL",
                    color = CinemaCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        // BGM Preset Cards
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(AudioLibrary.bgmPresets) { bgm ->
                val isSelected = bgm.id == project.bgmPresetId
                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaAmberGold else CinemaBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .width(160.dp)
                        .clickable {
                            onAudioSettingsChanged(bgm.id, project.bgmVolume, project.voiceVolume, project.duckingEnabled)
                        }
                        .testTag("bgm_preset_${bgm.id}")
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(14.dp))
                            Text(bgm.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(bgm.genre, color = CinemaCyan, fontSize = 9.sp)
                        Text(bgm.mood, color = Color.Gray, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Audio Sliders & Ducking
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("BGM Level:", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.width(68.dp))
            Slider(
                value = project.bgmVolume,
                onValueChange = {
                    onAudioSettingsChanged(project.bgmPresetId, it, project.voiceVolume, project.duckingEnabled)
                },
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = CinemaAmberGold, activeTrackColor = CinemaAmberGold),
                modifier = Modifier
                    .weight(1f)
                    .testTag("bgm_volume_slider")
            )
            Text("${(project.bgmVolume * 100).toInt()}%", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(36.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Voice Level:", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.width(68.dp))
            Slider(
                value = project.voiceVolume,
                onValueChange = {
                    onAudioSettingsChanged(project.bgmPresetId, project.bgmVolume, it, project.duckingEnabled)
                },
                valueRange = 0f..1.5f,
                colors = SliderDefaults.colors(thumbColor = CinemaCyan, activeTrackColor = CinemaCyan),
                modifier = Modifier
                    .weight(1f)
                    .testTag("voice_volume_slider")
            )
            Text("${(project.voiceVolume * 100).toInt()}%", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(36.dp))
        }

        // Voice Ducking Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CinemaSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Smart Narration Ducking", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text("Attenuates BGM by -12dB when narration audio plays", color = Color.Gray, fontSize = 10.sp)
            }
            Switch(
                checked = project.duckingEnabled,
                onCheckedChange = {
                    onAudioSettingsChanged(project.bgmPresetId, project.bgmVolume, project.voiceVolume, it)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = CinemaAmberGold,
                    checkedTrackColor = CinemaAmberGold.copy(alpha = 0.4f)
                ),
                modifier = Modifier.testTag("ducking_switch")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sound Effects (SFX) Cues for Active Slide
        Text(
            text = "Slide SFX Cue (${if (activeSlide != null) "Slide #${activeSlide.serialOrder}" else "No slide selected"})",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Text("Trigger dramatic sound hits, camera snaps, or transition whooshes", color = Color.Gray, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Option to clear SFX
            item {
                Surface(
                    color = if (activeSlide?.soundEffectCue == null) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (activeSlide?.soundEffectCue == null) CinemaCyan else CinemaBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.clickable { onSlideSfxChanged(null) }
                ) {
                    Text(
                        text = "None",
                        color = if (activeSlide?.soundEffectCue == null) CinemaCyan else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }

            items(AudioLibrary.soundEffects) { sfx ->
                val isSelected = activeSlide?.soundEffectCue == sfx.id
                Surface(
                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) CinemaAmberGold else CinemaBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .clickable { onSlideSfxChanged(sfx.id) }
                        .testTag("sfx_${sfx.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(12.dp))
                        }
                        Text(
                            text = sfx.name,
                            color = if (isSelected) Color.White else Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
