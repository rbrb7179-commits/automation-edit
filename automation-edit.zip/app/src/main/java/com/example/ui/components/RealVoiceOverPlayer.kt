package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.media.AudioFileInfo
import com.example.data.media.MediaHelper
import com.example.data.media.RealAudioPlayerState
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCoral
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun RealVoiceOverPlayer(
    project: ProjectEntity,
    audioPlayerState: RealAudioPlayerState,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onStop: () -> Unit,
    onUploadAudio: (AudioFileInfo) -> Unit,
    onRemoveAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // SAF Audio Picker for MP3, WAV, M4A, AAC, OGG
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            MediaHelper.takePersistableUriPermissionSafe(context, uri)
            val info = MediaHelper.extractAudioInfo(context, uri)
            onUploadAudio(info)
        }
    }

    val hasAudio = !project.voiceAudioUri.isNullOrEmpty()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // Section Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Narration Voice-Over Audio",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Supports MP3, WAV, M4A, AAC & OGG via Android Storage Access Framework",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
            }

            if (hasAudio) {
                Surface(
                    color = CinemaEmerald.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CinemaEmerald),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "AUDIO LOADED",
                        color = CinemaEmerald,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (!hasAudio) {
            // Empty State: Prompt Upload
            Card(
                colors = CardDefaults.cardColors(containerColor = CinemaSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = null,
                        tint = CinemaCyan,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No Voice-Over Audio Uploaded",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Upload a documentary voice track to listen, pause, seek,\nand automatically sync visual slides to spoken timing.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            audioPicker.launch(
                                arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/m4a", "audio/aac", "audio/*")
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaAmberGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("upload_voiceover_btn")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Select Voice-Over File (SAF)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Real Audio Player Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CinemaSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Header: Filename, File Size, Duration & Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = CinemaCyan.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = CinemaCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = project.voiceAudioFileName ?: "voice_over_narration.wav",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${MediaHelper.formatDuration(project.voiceAudioDurationSec)} • ${MediaHelper.formatFileSize(project.voiceAudioFileSize)}",
                                    color = Color.LightGray,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Replace Audio Button
                            OutlinedButton(
                                onClick = {
                                    audioPicker.launch(
                                        arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/m4a", "audio/aac", "audio/*")
                                    )
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaCyan),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("replace_voiceover_btn")
                            ) {
                                Icon(Icons.Default.ChangeCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Replace", fontSize = 10.sp)
                            }

                            // Delete Audio Button
                            IconButton(
                                onClick = onRemoveAudio,
                                modifier = Modifier.size(32.dp).testTag("delete_voiceover_btn")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete audio", tint = CinemaCoral, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Audio Error Warning if any
                    if (audioPlayerState.errorMessage != null) {
                        Surface(
                            color = CinemaCoral.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCoral),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = CinemaCoral, modifier = Modifier.size(16.dp))
                                Text(audioPlayerState.errorMessage, color = Color.White, fontSize = 10.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // Dynamic Waveform Visualizer Bar
                    AudioWaveformVisualizer(
                        isPlaying = audioPlayerState.isPlaying,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(CinemaBackground, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Real Playback Transport: Play/Pause, Stop, Draggable Seek Slider
                    val durMs = if (audioPlayerState.durationMs > 0) audioPlayerState.durationMs
                                else (project.voiceAudioDurationSec * 1000L).toLong().coerceAtLeast(1000L)
                    val posMs = audioPlayerState.currentPositionMs.coerceIn(0L, durMs)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Play / Pause Button
                        IconButton(
                            onClick = onPlayPause,
                            modifier = Modifier
                                .size(36.dp)
                                .background(CinemaAmberGold, CircleShape)
                                .testTag("voice_play_pause_btn")
                        ) {
                            Icon(
                                imageVector = if (audioPlayerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (audioPlayerState.isPlaying) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Stop Button
                        IconButton(
                            onClick = onStop,
                            modifier = Modifier
                                .size(32.dp)
                                .background(CinemaSurfaceVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                        }

                        // Scrubber Slider
                        Slider(
                            value = posMs.toFloat(),
                            onValueChange = { onSeek(it.toLong()) },
                            valueRange = 0f..durMs.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = CinemaAmberGold,
                                activeTrackColor = CinemaAmberGold,
                                inactiveTrackColor = CinemaBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("voice_seek_slider")
                        )

                        // Timecode Display: Current / Total
                        Text(
                            text = "${MediaHelper.formatDuration(posMs / 1000f)} / ${MediaHelper.formatDuration(durMs / 1000f)}",
                            color = CinemaCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioWaveformVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val animatedPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(modifier = modifier) {
        val barCount = 36
        val barWidth = size.width / (barCount * 1.5f)
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val x = i * (barWidth * 1.5f) + barWidth / 2f
            // Wave calculation simulating documentary voice cadence
            val sinBase = kotlin.math.sin(i * 0.45 + (if (isPlaying) animatedPhase * 6.28 else 0.0)).toFloat()
            val heightFraction = if (isPlaying) {
                (0.25f + kotlin.math.abs(sinBase) * 0.65f).coerceIn(0.15f, 0.95f)
            } else {
                (0.2f + kotlin.math.abs(sinBase) * 0.3f).coerceIn(0.1f, 0.5f)
            }

            val barHeight = size.height * heightFraction

            drawLine(
                color = if (isPlaying) CinemaEmerald else Color.DarkGray,
                start = Offset(x, centerY - barHeight / 2f),
                end = Offset(x, centerY + barHeight / 2f),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }
    }
}
