package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant
import com.example.ui.theme.PlayheadColor
import com.example.ui.theme.TrackAudioBorder
import com.example.ui.theme.TrackAudioColor
import com.example.ui.theme.TrackCaptionBorder
import com.example.ui.theme.TrackCaptionColor
import com.example.ui.theme.TrackSfxBorder
import com.example.ui.theme.TrackSfxColor
import com.example.ui.theme.TrackVideoBorder
import com.example.ui.theme.TrackVideoColor

@Composable
fun MultiTrackTimeline(
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    activeSlide: MediaSlideEntity?,
    currentPositionSec: Float,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onSeekTo: (Float) -> Unit,
    onSelectSlide: (Int) -> Unit,
    onMoveSlideLeft: (Int) -> Unit,
    onMoveSlideRight: (Int) -> Unit,
    onDeleteSlide: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalDuration = remember(slides) {
        slides.sumOf { it.durationSeconds.toDouble() }.toFloat().coerceAtLeast(1f)
    }

    // Pixels per second for horizontal timeline layout
    val dpPerSecond = 28.dp
    val totalTimelineWidth = dpPerSecond * (totalDuration + 2f)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CinemaSurface)
            .border(1.dp, CinemaBorder)
    ) {
        // Timeline Header: Playhead controls & Transport buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CinemaBackground)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Rewind
                IconButton(
                    onClick = { onSeekTo(0f) },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("timeline_rewind_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "Rewind",
                        tint = Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Play / Pause
                IconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier
                        .size(38.dp)
                        .background(CinemaAmberGold, CircleShape)
                        .testTag("timeline_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Timecode
                Text(
                    text = String.format("%02d:%04.1f", (currentPositionSec / 60).toInt(), currentPositionSec % 60),
                    color = CinemaCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = String.format("/ %02d:%04.1f", (totalDuration / 60).toInt(), totalDuration % 60),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            // Sync mode indicator tag
            Surface(
                color = if (project.syncMode == "SMART_AI") CinemaCyan.copy(alpha = 0.2f) else CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (project.syncMode == "SMART_AI") CinemaCyan else CinemaBorder
                ),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = if (project.syncMode == "SMART_AI") "✦ SMART AI SYNC" else "SEQUENTIAL SYNC",
                    color = if (project.syncMode == "SMART_AI") CinemaCyan else Color.LightGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Horizontal Multi-Track Container
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
        ) {
            // Left Track Labels Column (Fixed)
            Column(
                modifier = Modifier
                    .width(76.dp)
                    .fillMaxHeight()
                    .background(CinemaSurfaceElevated)
                    .border(androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder))
            ) {
                // Ruler space
                Box(
                    modifier = Modifier
                        .height(24.dp)
                        .fillMaxWidth()
                        .background(CinemaBackground),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text("TIME", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
                }

                // Video / Slide Track Label
                TrackLabel(
                    title = "V1 Slides",
                    icon = Icons.Default.Movie,
                    color = TrackVideoBorder,
                    modifier = Modifier.height(72.dp)
                )

                // Voiceover Audio Track Label
                TrackLabel(
                    title = "A1 Voice",
                    icon = Icons.Default.GraphicEq,
                    color = TrackAudioBorder,
                    modifier = Modifier.height(38.dp)
                )

                // BGM / SFX Track Label
                TrackLabel(
                    title = "A2 Music",
                    icon = Icons.Default.Audiotrack,
                    color = TrackSfxBorder,
                    modifier = Modifier.height(38.dp)
                )

                // Captions Track Label
                TrackLabel(
                    title = "CC Subtitle",
                    icon = Icons.Default.Subtitles,
                    color = TrackCaptionBorder,
                    modifier = Modifier.height(38.dp)
                )
            }

            // Scrollable Timeline Tracks with Playhead scrubber
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .horizontalScroll(scrollState)
                    .pointerInput(totalDuration) {
                        detectTapGestures { offset ->
                            val clickedSec = (offset.x / (dpPerSecond.toPx())).coerceIn(0f, totalDuration)
                            onSeekTo(clickedSec)
                        }
                    }
            ) {
                Column(modifier = Modifier.width(totalTimelineWidth)) {
                    // 1. Time Ruler Bar
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .background(CinemaBackground)
                    ) {
                        val pxPerSec = dpPerSecond.toPx()
                        val maxSec = totalDuration.toInt() + 2
                        for (sec in 0..maxSec) {
                            val x = sec * pxPerSec
                            // Major tick every 2 seconds
                            if (sec % 2 == 0) {
                                drawLine(
                                    color = Color.LightGray.copy(alpha = 0.5f),
                                    start = Offset(x, 10f),
                                    end = Offset(x, 24f),
                                    strokeWidth = 1.5f
                                )
                            } else {
                                drawLine(
                                    color = Color.DarkGray,
                                    start = Offset(x, 16f),
                                    end = Offset(x, 24f),
                                    strokeWidth = 1f
                                )
                            }
                        }
                    }

                    // 2. Track 1: Visual Slides
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .background(CinemaSurfaceVariant.copy(alpha = 0.5f))
                            .border(0.5.dp, CinemaBorder)
                    ) {
                        slides.forEachIndexed { index, slide ->
                            val isSelected = activeSlide?.id == slide.id
                            val slideWidth = dpPerSecond * slide.durationSeconds

                            Box(
                                modifier = Modifier
                                    .width(slideWidth)
                                    .fillMaxHeight()
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) TrackVideoBorder.copy(alpha = 0.3f) else TrackVideoColor)
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) CinemaAmberGold else TrackVideoBorder,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable { onSelectSlide(index) }
                                    .testTag("timeline_slide_$index")
                            ) {
                                Row(modifier = Modifier.fillMaxSize()) {
                                    // Thumbnail
                                    AsyncImage(
                                        model = slide.imageUri,
                                        contentDescription = slide.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp))
                                    )
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 4.dp, vertical = 2.dp),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "#${slide.serialOrder} ${slide.title}",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                slide.syncConfidenceScore?.let { score ->
                                                    val pct = (score * 100).toInt()
                                                    Surface(
                                                        color = if (pct >= 85) CinemaCyan.copy(alpha = 0.25f) else CinemaAmberGold.copy(alpha = 0.25f),
                                                        shape = RoundedCornerShape(2.dp)
                                                    ) {
                                                        Text(
                                                            text = "$pct%",
                                                            color = if (pct >= 85) CinemaCyan else CinemaAmberGold,
                                                            fontSize = 7.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 2.dp)
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = "${slide.durationSeconds}s",
                                                    color = CinemaAmberGold,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }

                                        // Move controls & SFX badge
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                if (index > 0) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowBack,
                                                        contentDescription = "Move Left",
                                                        tint = Color.White.copy(alpha = 0.8f),
                                                        modifier = Modifier
                                                            .size(16.dp)
                                                            .clickable { onMoveSlideLeft(index) }
                                                    )
                                                }
                                                if (index < slides.size - 1) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowForward,
                                                        contentDescription = "Move Right",
                                                        tint = Color.White.copy(alpha = 0.8f),
                                                        modifier = Modifier
                                                            .size(16.dp)
                                                            .clickable { onMoveSlideRight(index) }
                                                    )
                                                }
                                            }

                                            if (slide.soundEffectCue != null) {
                                                Surface(
                                                    color = TrackSfxColor,
                                                    shape = RoundedCornerShape(2.dp)
                                                ) {
                                                    Text(
                                                        text = "SFX",
                                                        color = Color.White,
                                                        fontSize = 7.sp,
                                                        modifier = Modifier.padding(horizontal = 2.dp)
                                                    )
                                                }
                                            }

                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete slide",
                                                tint = Color.LightGray.copy(alpha = 0.6f),
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable { onDeleteSlide(slide.id) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. Track 2: Voiceover Audio Track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .background(CinemaBackground)
                            .border(0.5.dp, CinemaBorder)
                    ) {
                        val voiceDuration = project.voiceAudioDurationSec.coerceAtLeast(totalDuration)
                        val voiceWidth = dpPerSecond * voiceDuration

                        Row(
                            modifier = Modifier
                                .width(voiceWidth)
                                .fillMaxHeight()
                                .padding(vertical = 2.dp, horizontal = 2.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TrackAudioColor)
                                .border(1.dp, TrackAudioBorder, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text(
                                    text = project.voiceAudioFileName ?: "Narrator Audio Sync Track",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${voiceDuration.toInt()}s • ${if (project.duckingEnabled) "Ducked" else "Full"}",
                                color = Color(0xFFA7F3D0),
                                fontSize = 9.sp
                            )
                        }
                    }

                    // 4. Track 3: BGM & Sound Effects Track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .background(CinemaSurfaceVariant.copy(alpha = 0.4f))
                            .border(0.5.dp, CinemaBorder)
                    ) {
                        val bgmWidth = dpPerSecond * totalDuration

                        Box(
                            modifier = Modifier
                                .width(bgmWidth)
                                .fillMaxHeight()
                                .padding(vertical = 2.dp, horizontal = 2.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TrackSfxColor)
                                .border(1.dp, TrackSfxBorder, RoundedCornerShape(3.dp))
                                .padding(horizontal = 6.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "BGM: ${project.bgmPresetId.replace("_", " ").uppercase()} (${(project.bgmVolume * 100).toInt()}%)",
                                color = Color.White,
                                fontSize = 9.sp
                            )
                        }
                    }

                    // 5. Track 4: Captions Track
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .background(CinemaBackground)
                            .border(0.5.dp, CinemaBorder)
                    ) {
                        slides.forEach { slide ->
                            val capWidth = dpPerSecond * slide.durationSeconds
                            Box(
                                modifier = Modifier
                                    .width(capWidth)
                                    .fillMaxHeight()
                                    .padding(vertical = 2.dp, horizontal = 2.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (project.autoCaptionsEnabled) TrackCaptionColor else Color.DarkGray)
                                    .border(
                                        0.5.dp,
                                        if (project.autoCaptionsEnabled) TrackCaptionBorder else Color.Gray,
                                        RoundedCornerShape(3.dp)
                                    )
                                    .padding(horizontal = 4.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = if (project.autoCaptionsEnabled) {
                                        slide.captionSnippet.ifBlank { "..." }
                                    } else "Captions Disabled",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Dynamic Scrubber Playhead Line
                val playheadX = dpPerSecond * currentPositionSec
                Box(
                    modifier = Modifier
                        .offset(x = playheadX - 1.dp)
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(PlayheadColor)
                )
                // Playhead top triangle handle
                Box(
                    modifier = Modifier
                        .offset(x = playheadX - 5.dp, y = 0.dp)
                        .size(10.dp)
                        .background(PlayheadColor, RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                )
            }
        }
    }
}

@Composable
private fun TrackLabel(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .border(0.5.dp, CinemaBorder)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(14.dp))
        Text(
            text = title,
            color = Color.LightGray,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
