package com.example.ui.components

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.KeyboardDoubleArrowDown
import androidx.compose.material.icons.filled.KeyboardDoubleArrowUp
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.data.media.MediaHelper
import com.example.data.model.MediaSlideEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCoral
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun MediaSequenceGrid(
    slides: List<MediaSlideEntity>,
    activeSlideId: Long?,
    isUploading: Boolean,
    onSelectSlide: (Int) -> Unit,
    onAddImages: (List<Pair<String, String>>) -> Unit,
    onReplaceImage: (slideId: Long, newUri: String, newTitle: String?) -> Unit,
    onDeleteSlide: (slideId: Long) -> Unit,
    onMoveSlide: (fromIndex: Int, toIndex: Int) -> Unit,
    onMoveToTop: (fromIndex: Int) -> Unit,
    onMoveToEnd: (fromIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var replacingSlideId by remember { mutableStateOf<Long?>(null) }

    // Multi-image Photo Picker (Modern Android 13+ standard with backwards compat)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexed { idx, uri ->
                MediaHelper.takePersistableUriPermissionSafe(context, uri)
                val (name, _) = MediaHelper.getFileNameAndSize(context, uri)
                Pair(uri.toString(), name.ifBlank { "Image #${slides.size + idx + 1}" })
            }
            onAddImages(list)
        }
    }

    // Storage Access Framework Multi-Document Picker (Supports JPG, JPEG, PNG, WebP)
    val safDocPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexed { idx, uri ->
                MediaHelper.takePersistableUriPermissionSafe(context, uri)
                val (name, _) = MediaHelper.getFileNameAndSize(context, uri)
                Pair(uri.toString(), name.ifBlank { "Documentary Slide #${slides.size + idx + 1}" })
            }
            onAddImages(list)
        }
    }

    // Single image replacement picker
    val replacePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        val targetId = replacingSlideId
        if (uri != null && targetId != null) {
            MediaHelper.takePersistableUriPermissionSafe(context, uri)
            val (name, _) = MediaHelper.getFileNameAndSize(context, uri)
            onReplaceImage(targetId, uri.toString(), name)
        }
        replacingSlideId = null
    }

    val totalDurationSec = remember(slides) {
        slides.sumOf { it.durationSeconds.toDouble() }.toFloat()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // Top Toolbar: Total Count, Total Duration & Upload Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Documentary Image Sequence",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Surface(
                        color = CinemaAmberGold.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CinemaAmberGold),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "${slides.size} IMAGES",
                            color = CinemaAmberGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Total visual duration: ${MediaHelper.formatDuration(totalDurationSec)} • Drag & reorder sequence below",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
            }

            // Upload action buttons
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Photo Picker Button
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CinemaAmberGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("btn_select_images_photopicker")
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Photos", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Storage Access Framework Button (PNG, JPG, WebP)
                OutlinedButton(
                    onClick = {
                        safDocPickerLauncher.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaCyan),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("btn_select_images_saf")
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Storage Files", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Upload progress indicator if batch importing
        if (isUploading) {
            Surface(
                color = CinemaSurfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        color = CinemaAmberGold,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    )
                    Text("Importing images and registering sequence in project...", color = Color.White, fontSize = 11.sp)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Empty state
        if (slides.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(CinemaSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, CinemaBorder, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Images Uploaded", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        "Tap 'Add Photos' or 'Storage Files' above to import\nJPG, JPEG, PNG, or WebP images from your device.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // High efficiency LazyVerticalGrid supporting large image collections
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                itemsIndexed(
                    items = slides,
                    key = { _, slide -> slide.id }
                ) { index, slide ->
                    val isSelected = slide.id == activeSlideId

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSlide(index) }
                            .testTag("media_grid_card_${slide.serialOrder}"),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) CinemaSurfaceElevated else CinemaSurface
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) CinemaAmberGold else CinemaBorder
                        )
                    ) {
                        Column {
                            // Thumbnail container with absolute serial badge & replace button
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 10f)
                                    .background(Color.Black)
                            ) {
                                SubcomposeAsyncImage(
                                    model = slide.imageUri,
                                    contentDescription = slide.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                    loading = {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(color = CinemaCyan, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        }
                                    },
                                    error = {
                                        Box(
                                            Modifier
                                                .fillMaxSize()
                                                .background(CinemaBackground),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Default.BrokenImage, contentDescription = null, tint = CinemaCoral, modifier = Modifier.size(24.dp))
                                                Text("Missing File", color = CinemaCoral, fontSize = 9.sp)
                                            }
                                        }
                                    }
                                )

                                // Number Badge in Upload Order (e.g. #1, #2...)
                                Surface(
                                    color = if (isSelected) CinemaAmberGold else Color.Black.copy(alpha = 0.75f),
                                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                                    modifier = Modifier.align(Alignment.TopStart)
                                ) {
                                    Text(
                                        text = "#${slide.serialOrder}",
                                        color = if (isSelected) Color.Black else Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                    )
                                }

                                // Quick Replace action button overlay on top right
                                Surface(
                                    color = Color.Black.copy(alpha = 0.65f),
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(26.dp)
                                        .clickable {
                                            replacingSlideId = slide.id
                                            replacePickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                        .testTag("replace_slide_${slide.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChangeCircle,
                                        contentDescription = "Replace Image",
                                        tint = CinemaCyan,
                                        modifier = Modifier.padding(4.dp)
                                    )
                                }

                                // Confidence score pill bottom left
                                slide.syncConfidenceScore?.let { score ->
                                    val percent = (score * 100).toInt()
                                    Surface(
                                        color = if (percent >= 85) CinemaCyan.copy(alpha = 0.85f) else CinemaAmberGold.copy(alpha = 0.85f),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(4.dp)
                                    ) {
                                        Text(
                                            text = "$percent% SYNC",
                                            color = Color.Black,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                // Duration pill bottom right
                                Surface(
                                    color = Color.Black.copy(alpha = 0.75f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                ) {
                                    Text(
                                        text = "${slide.durationSeconds}s",
                                        color = CinemaAmberGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Card Information & Reordering Controls
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = slide.title.ifBlank { "Slide #${slide.serialOrder}" },
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = "${MediaHelper.formatDuration(slide.startTimeSec)} - ${MediaHelper.formatDuration(slide.endTimeSec)}",
                                    color = CinemaCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Reordering Bar
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Move controls
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        // Move to Top
                                        if (index > 0) {
                                            IconButton(
                                                onClick = { onMoveToTop(index) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.KeyboardDoubleArrowUp, contentDescription = "Move to Top", tint = CinemaCyan, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        // Move Backward
                                        if (index > 0) {
                                            IconButton(
                                                onClick = { onMoveSlide(index, index - 1) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        // Move Forward
                                        if (index < slides.size - 1) {
                                            IconButton(
                                                onClick = { onMoveSlide(index, index + 1) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        // Move to End
                                        if (index < slides.size - 1) {
                                            IconButton(
                                                onClick = { onMoveToEnd(index) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.KeyboardDoubleArrowDown, contentDescription = "Move to End", tint = CinemaCyan, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }

                                    // Delete button
                                    IconButton(
                                        onClick = { onDeleteSlide(slide.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CinemaCoral.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
