package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AspectRatioType
import com.example.data.model.FrameRateType
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ResolutionType
import com.example.data.model.VideoCodecType
import com.example.integration.FFmpegRenderPipeline
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaEmerald
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ExportSettingsDialog(
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    onDismiss: () -> Unit,
    onSaveExportSettings: (AspectRatioType, ResolutionType, FrameRateType, VideoCodecType) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedAspect by remember {
        mutableStateOf(runCatching { AspectRatioType.valueOf(project.aspectRatio) }.getOrDefault(AspectRatioType.LANDSCAPE_16_9))
    }
    var selectedRes by remember {
        mutableStateOf(runCatching { ResolutionType.valueOf(project.resolution) }.getOrDefault(ResolutionType.RES_1080P))
    }
    var selectedFps by remember {
        mutableStateOf(runCatching { FrameRateType.valueOf(project.frameRate) }.getOrDefault(FrameRateType.FPS_24))
    }
    var selectedCodec by remember {
        mutableStateOf(runCatching { VideoCodecType.valueOf(project.codec) }.getOrDefault(VideoCodecType.CODEC_H264))
    }

    var showFfmpegCommand by remember { mutableStateOf(false) }
    var isSimulatingRender by remember { mutableStateOf(false) }
    var renderProgress by remember { mutableFloatStateOf(0f) }
    var renderStage by remember { mutableStateOf("") }
    var renderCompleted by remember { mutableStateOf(false) }

    val ffmpegCommand = remember(project, slides, selectedAspect, selectedRes, selectedFps, selectedCodec) {
        val tempProj = project.copy(
            aspectRatio = selectedAspect.name,
            resolution = selectedRes.name,
            frameRate = selectedFps.name,
            codec = selectedCodec.name
        )
        FFmpegRenderPipeline.buildFullCommand(tempProj, slides)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp),
            shape = RoundedCornerShape(12.dp),
            color = CinemaSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(24.dp))
                        Column {
                            Text("Export Documentary Video", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Aspect ratio, 4K/1080p resolution & FFmpeg pipeline", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Aspect Ratio Section (YouTube Shorts 9:16 vs Long Video 16:9)
                Text("1. Aspect Ratio Format", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AspectRatioType.values().forEach { aspect ->
                        val isSelected = aspect == selectedAspect
                        Surface(
                            color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) CinemaAmberGold else CinemaBorder
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedAspect = aspect
                                    onSaveExportSettings(aspect, selectedRes, selectedFps, selectedCodec)
                                }
                                .testTag("export_aspect_${aspect.name.lowercase()}")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = aspect.label,
                                    color = if (isSelected) CinemaAmberGold else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(aspect.dimensionLabel, color = Color.Gray, fontSize = 9.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Resolution (1080p vs 4K)
                Text("2. Target Resolution", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ResolutionType.values().forEach { res ->
                        val isSelected = res == selectedRes
                        Surface(
                            color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) CinemaCyan else CinemaBorder
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedRes = res
                                    onSaveExportSettings(selectedAspect, res, selectedFps, selectedCodec)
                                }
                                .testTag("export_res_${res.name.lowercase()}")
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = res.label.substringBefore(" ("),
                                    color = if (isSelected) CinemaCyan else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = if (res == ResolutionType.RES_4K) "Cinematic UHD" else "Standard FHD",
                                    color = Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Frame Rate & Codec
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Frame Rate
                    Column(modifier = Modifier.weight(1f)) {
                        Text("3. Frame Rate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FrameRateType.values().forEach { fps ->
                                val isSelected = fps == selectedFps
                                Surface(
                                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) CinemaAmberGold else CinemaBorder
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedFps = fps
                                            onSaveExportSettings(selectedAspect, selectedRes, fps, selectedCodec)
                                        }
                                ) {
                                    Text(
                                        text = "${fps.fps}fps",
                                        color = if (isSelected) CinemaAmberGold else Color.LightGray,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(vertical = 6.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    // Codec
                    Column(modifier = Modifier.weight(1f)) {
                        Text("4. Video Codec", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            VideoCodecType.values().forEach { codec ->
                                val isSelected = codec == selectedCodec
                                Surface(
                                    color = if (isSelected) CinemaSurfaceElevated else CinemaSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) CinemaCyan else CinemaBorder
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedCodec = codec
                                            onSaveExportSettings(selectedAspect, selectedRes, selectedFps, codec)
                                        }
                                ) {
                                    Text(
                                        text = if (codec == VideoCodecType.CODEC_H264) "H.264" else "HEVC",
                                        color = if (isSelected) CinemaCyan else Color.LightGray,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(vertical = 6.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Spacer(modifier = Modifier.height(14.dp))

                // Render Destination Mode Selector
                Text("5. Export Engine Target", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                var renderMode by remember { mutableStateOf("LOCAL") } // "LOCAL" or "CLOUD"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = if (renderMode == "LOCAL") CinemaSurfaceElevated else CinemaSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            if (renderMode == "LOCAL") CinemaAmberGold else CinemaBorder
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { renderMode = "LOCAL" }
                            .testTag("render_mode_local")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("📱 On-Device Render", color = if (renderMode == "LOCAL") CinemaAmberGold else Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("Encodes MP4 locally via MediaCodec & Muxer", color = Color.Gray, fontSize = 9.sp)
                        }
                    }

                    Surface(
                        color = if (renderMode == "CLOUD") CinemaSurfaceElevated else CinemaSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            if (renderMode == "CLOUD") CinemaCyan else CinemaBorder
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { renderMode = "CLOUD" }
                            .testTag("render_mode_cloud")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("☁️ Cloud Worker", color = if (renderMode == "CLOUD") CinemaCyan else Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("Cloud Run FFmpeg queue & 4K cluster", color = Color.Gray, fontSize = 9.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle FFmpeg Command Script
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showFfmpegCommand = !showFfmpegCommand }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = CinemaCyan, modifier = Modifier.size(16.dp))
                        Text("View Production FFmpeg Command", color = CinemaCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(if (showFfmpegCommand) "Hide ▲" else "Show ▼", color = Color.Gray, fontSize = 10.sp)
                }

                AnimatedVisibility(visible = showFfmpegCommand) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CinemaBackground, RoundedCornerShape(6.dp))
                            .border(1.dp, CinemaBorder, RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Generated Render Script", color = Color.Gray, fontSize = 10.sp)
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("FFmpeg Command", ffmpegCommand))
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CinemaAmberGold, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = ffmpegCommand,
                            color = Color(0xFFA5F3FC),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            lineHeight = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Subtitle SRT Export Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CinemaSurfaceVariant, RoundedCornerShape(8.dp))
                        .border(1.dp, CinemaBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("SubRip Subtitle File (.srt)", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        Text("Export timestamps and captions to SRT", color = Color.Gray, fontSize = 9.sp)
                    }
                    Button(
                        onClick = {
                            val srt = com.example.integration.SrtSubtitleGenerator.generateSrt(slides)
                            val file = com.example.integration.SrtSubtitleGenerator.saveSrtToFile(context, project.id, srt)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Subtitles SRT", srt))
                            android.widget.Toast.makeText(context, "SRT copied to clipboard & saved to ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaSurfaceElevated, contentColor = CinemaCyan),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Export SRT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Variables for output MP4 file
                var renderedFile by remember { mutableStateOf<java.io.File?>(null) }
                var renderedUri by remember { mutableStateOf<android.net.Uri?>(null) }
                var renderedFileSizeMb by remember { mutableFloatStateOf(0f) }

                // Render Progress Box
                if (isSimulatingRender) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CinemaSurfaceVariant, RoundedCornerShape(8.dp))
                            .border(1.dp, CinemaCyan, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (renderMode == "LOCAL") "Local MediaCodec Encoder Active" else "Cloud Render Worker Active",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text("${(renderProgress * 100).toInt()}%", color = CinemaCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { renderProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = CinemaAmberGold,
                            trackColor = CinemaBackground
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(renderStage, color = Color.LightGray, fontSize = 10.sp)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Render Completed Banner
                if (renderCompleted) {
                    Surface(
                        color = CinemaEmerald.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CinemaEmerald),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CinemaEmerald, modifier = Modifier.size(20.dp))
                                Column {
                                    Text("Video Rendering Completed!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(
                                        text = if (renderedFile != null)
                                            "File: ${renderedFile?.name} (${String.format("%.1f", renderedFileSizeMb)} MB)"
                                        else
                                            "Rendered on Cloud Worker. Ready for download.",
                                        color = Color.LightGray,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            if (renderedUri != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val playIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                                setDataAndType(renderedUri, "video/mp4")
                                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(playIntent, "Play Documentary Video"))
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CinemaAmberGold, contentColor = Color.Black),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Play Video", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                type = "video/mp4"
                                                putExtra(android.content.Intent.EXTRA_STREAM, renderedUri)
                                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Documentary MP4"))
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CinemaCyan),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Share MP4", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Close", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (!isSimulatingRender) {
                                isSimulatingRender = true
                                renderCompleted = false
                                renderProgress = 0.05f
                                renderStage = "Preparing video pipeline..."

                                val exportProj = project.copy(
                                    aspectRatio = selectedAspect.name,
                                    resolution = selectedRes.name,
                                    frameRate = selectedFps.name,
                                    codec = selectedCodec.name
                                )

                                scope.launch {
                                    if (renderMode == "LOCAL") {
                                        com.example.integration.LocalVideoRenderer.renderProject(context, exportProj, slides)
                                            .collect { state ->
                                                when (state) {
                                                    is com.example.integration.LocalVideoRenderer.ExportState.Preparing -> {
                                                        renderStage = state.message
                                                        renderProgress = 0.20f
                                                    }
                                                    is com.example.integration.LocalVideoRenderer.ExportState.Rendering -> {
                                                        renderStage = "Encoding slide ${state.currentSlide + 1}/${state.totalSlides} at ${state.fps} fps"
                                                        renderProgress = 0.20f + (state.progress * 0.60f)
                                                    }
                                                    is com.example.integration.LocalVideoRenderer.ExportState.Muxing -> {
                                                        renderStage = state.message
                                                        renderProgress = 0.90f
                                                    }
                                                    is com.example.integration.LocalVideoRenderer.ExportState.Completed -> {
                                                        renderStage = "Export complete!"
                                                        renderProgress = 1.0f
                                                        renderedFile = state.outputFile
                                                        renderedUri = state.contentUri
                                                        renderedFileSizeMb = state.fileSizeBytes / (1024f * 1024f)
                                                        isSimulatingRender = false
                                                        renderCompleted = true
                                                    }
                                                    is com.example.integration.LocalVideoRenderer.ExportState.Failed -> {
                                                        renderStage = "Error: ${state.error}"
                                                        isSimulatingRender = false
                                                    }
                                                    else -> {}
                                                }
                                            }
                                    } else {
                                        // Cloud worker submission
                                        renderStage = "Submitting render job to cloud worker pool..."
                                        renderProgress = 0.20f
                                        val cloudService = com.example.integration.CloudRenderServiceImpl()
                                        val job = cloudService.submitRenderJob(exportProj, slides)

                                        renderStage = "Cloud worker rendering filters & audio mixing..."
                                        renderProgress = 0.60f
                                        delay(1200)

                                        renderStage = "Finalizing cloud MP4 artifact..."
                                        renderProgress = 0.95f
                                        delay(600)

                                        renderProgress = 1.0f
                                        renderStage = "Cloud render complete!"
                                        isSimulatingRender = false
                                        renderCompleted = true
                                    }
                                }
                            }
                        },
                        enabled = !isSimulatingRender,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("start_render_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaAmberGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSimulatingRender) "Rendering..." else "Render MP4 Video",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

