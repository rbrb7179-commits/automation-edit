package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AspectRatioType
import com.example.data.model.CaptionPosition
import com.example.data.model.CaptionStyle
import com.example.data.model.ColorGradingPreset
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun VideoPreviewCanvas(
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    activeSlide: MediaSlideEntity?,
    currentPositionSec: Float,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val aspect = runCatching { AspectRatioType.valueOf(project.aspectRatio) }
        .getOrDefault(AspectRatioType.LANDSCAPE_16_9)
    val colorPreset = runCatching { ColorGradingPreset.valueOf(project.colorGradingPreset) }
        .getOrDefault(ColorGradingPreset.WARM_DOCUMENTARY)

    // Calculate progress within current active slide
    val slideProgress = remember(slides, activeSlide, currentPositionSec) {
        if (activeSlide == null || slides.isEmpty()) 0f
        else {
            var startTime = 0f
            for (slide in slides) {
                if (slide.id == activeSlide.id) break
                startTime += slide.durationSeconds
            }
            val elapsed = currentPositionSec - startTime
            val dur = activeSlide.durationSeconds.coerceAtLeast(0.1f)
            (elapsed / dur).coerceIn(0f, 1f)
        }
    }

    val motion = runCatching {
        activeSlide?.let { KenBurnsMotion.valueOf(it.kenBurnsMotion) } ?: KenBurnsMotion.SLOW_ZOOM_IN
    }.getOrDefault(KenBurnsMotion.SLOW_ZOOM_IN)

    // Ken Burns transform calculations based on progress
    val (scale, panX) = remember(motion, slideProgress) {
        when (motion) {
            KenBurnsMotion.SLOW_ZOOM_IN -> Pair(1.0f + 0.28f * slideProgress, 0f)
            KenBurnsMotion.SLOW_ZOOM_OUT -> Pair(1.28f - 0.28f * slideProgress, 0f)
            KenBurnsMotion.PAN_LEFT_TO_RIGHT -> Pair(1.18f, (-30f + 60f * slideProgress))
            KenBurnsMotion.PAN_RIGHT_TO_LEFT -> Pair(1.18f, (30f - 60f * slideProgress))
            KenBurnsMotion.DRAMATIC_PUSH -> Pair(1.0f + 0.45f * (slideProgress * slideProgress), 0f)
            KenBurnsMotion.STATIC_LOCKED -> Pair(1.0f, 0f)
        }
    }

    // Color Grading ColorMatrix
    val colorFilter = remember(colorPreset, project.gradingIntensity) {
        val sat = (1f + (colorPreset.saturation - 1f) * project.gradingIntensity).coerceAtLeast(0f)
        val contrast = 1f + (colorPreset.contrast - 1f) * project.gradingIntensity
        val brightness = colorPreset.brightness * 255f * project.gradingIntensity
        val warmShift = colorPreset.warmCoolBalance * project.gradingIntensity * 18f

        val invS = 1f - sat
        val rW = 0.2126f * invS
        val gW = 0.7152f * invS
        val bW = 0.0722f * invS

        val matrix = floatArrayOf(
            (rW + sat) * contrast, gW * contrast, bW * contrast, 0f, brightness + warmShift,
            rW * contrast, (gW + sat) * contrast, bW * contrast, 0f, brightness + warmShift * 0.4f,
            rW * contrast, gW * contrast, (bW + sat) * contrast, 0f, brightness - warmShift,
            0f, 0f, 0f, 1f, 0f
        )
        ColorFilter.colorMatrix(ColorMatrix(matrix))
    }

    val totalDuration = remember(slides) {
        slides.sumOf { it.durationSeconds.toDouble() }.toFloat().coerceAtLeast(1f)
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .background(CinemaBackground)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        // Enforce aspect ratio box container
        val isVertical = aspect == AspectRatioType.SHORTS_9_16
        val canvasModifier = if (isVertical) {
            Modifier
                .size(width = 180.dp, height = 320.dp)
                .clip(RoundedCornerShape(8.dp))
        } else {
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
        }

        Box(
            modifier = canvasModifier
                .background(Color.Black)
                .border(1.dp, CinemaBorder, RoundedCornerShape(8.dp))
                .clipToBounds()
                .clickable { onTogglePlay() }
                .testTag("video_preview_canvas"),
            contentAlignment = Alignment.Center
        ) {
            // Render active slide image with Ken Burns transform
            if (activeSlide != null) {
                AsyncImage(
                    model = activeSlide.imageUri,
                    contentDescription = activeSlide.title,
                    contentScale = ContentScale.Crop,
                    colorFilter = colorFilter,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = panX
                        }
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No slides in timeline.\nTap '+ Add Images' below to begin.",
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp
                    )
                }
            }

            // Top Status Bar Overlay (Aspect Ratio + Ken Burns Motion badge)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        color = CinemaAmberGold.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(3.dp)
                    ) {
                        Text(
                            text = aspect.label.substringBefore(" "),
                            color = Color.Black,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    Surface(
                        color = CinemaSurfaceVariant,
                        shape = RoundedCornerShape(3.dp)
                    ) {
                        Text(
                            text = project.resolution.removePrefix("RES_"),
                            color = CinemaCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                if (activeSlide != null) {
                    Text(
                        text = "Motion: ${motion.label}",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Captions Overlay (if enabled)
            if (project.autoCaptionsEnabled && activeSlide?.captionSnippet?.isNotBlank() == true) {
                val captionPos = runCatching { CaptionPosition.valueOf(project.captionPosition) }
                    .getOrDefault(CaptionPosition.BOTTOM)
                val captionAlignment = when (captionPos) {
                    CaptionPosition.TOP -> Alignment.TopCenter
                    CaptionPosition.MIDDLE -> Alignment.Center
                    CaptionPosition.BOTTOM -> Alignment.BottomCenter
                }

                val captionStyle = runCatching { CaptionStyle.valueOf(project.captionStyle) }
                    .getOrDefault(CaptionStyle.CINEMATIC_GOLD)

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(
                            top = if (captionPos == CaptionPosition.TOP) 24.dp else 4.dp,
                            bottom = if (captionPos == CaptionPosition.BOTTOM) 24.dp else 4.dp
                        )
                        .align(captionAlignment)
                ) {
                    when (captionStyle) {
                        CaptionStyle.CINEMATIC_GOLD -> {
                            Text(
                                text = activeSlide.captionSnippet,
                                color = CinemaAmberGold,
                                fontSize = if (isVertical) 13.sp else 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        CaptionStyle.BOLD_KARAOKE -> {
                            Text(
                                text = activeSlide.captionSnippet.uppercase(),
                                color = Color(0xFFFFEB3B),
                                fontSize = if (isVertical) 14.sp else 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        CaptionStyle.MODERN_CLEAN -> {
                            Text(
                                text = activeSlide.captionSnippet,
                                color = Color.White,
                                fontSize = if (isVertical) 12.sp else 11.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xCC1E293B), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        CaptionStyle.MINIMAL_BOX -> {
                            Text(
                                text = activeSlide.captionSnippet,
                                color = Color.White,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.85f))
                                    .border(0.5.dp, Color.White.copy(alpha = 0.3f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Timecode Display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format("TC %02d:%04.1f", (currentPositionSec / 60).toInt(), currentPositionSec % 60),
                    color = CinemaCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = String.format("TOTAL %02d:%04.1f", (totalDuration / 60).toInt(), totalDuration % 60),
                    color = Color.LightGray,
                    fontSize = 9.sp
                )
            }

            // Floating Play / Pause Overlay on Pause
            AnimatedVisibility(
                visible = !isPlaying,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = CircleShape,
                    modifier = Modifier.size(46.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = CinemaAmberGold,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                    )
                }
            }
        }
    }
}
