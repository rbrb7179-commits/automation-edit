package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CinematicDarkColorScheme = darkColorScheme(
    primary = CinemaAmberGold,
    onPrimary = CinemaBackground,
    primaryContainer = CinemaAmberGold.copy(alpha = 0.2f),
    onPrimaryContainer = CinemaAmberLight,
    secondary = CinemaCyan,
    onSecondary = CinemaBackground,
    secondaryContainer = CinemaCyan.copy(alpha = 0.2f),
    onSecondaryContainer = CinemaCyan,
    tertiary = CinemaCoral,
    onTertiary = CinemaBackground,
    background = CinemaBackground,
    onBackground = CinemaTextPrimary,
    surface = CinemaSurface,
    onSurface = CinemaTextPrimary,
    surfaceVariant = CinemaSurfaceVariant,
    onSurfaceVariant = CinemaTextSecondary,
    outline = CinemaBorder,
    outlineVariant = CinemaBorder.copy(alpha = 0.5f)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to professional dark cinematic interface
    content: @Composable () -> Unit
) {
    val colorScheme = CinematicDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = CinemaBackground.toArgb()
                it.navigationBarColor = CinemaBackground.toArgb()
                val insetsController = WindowCompat.getInsetsController(it, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
