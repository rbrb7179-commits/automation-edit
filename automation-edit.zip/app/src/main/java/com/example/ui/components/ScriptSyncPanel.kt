package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SyncMode
import com.example.ui.theme.CinemaAmberGold
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.CinemaBorder
import com.example.ui.theme.CinemaCyan
import com.example.ui.theme.CinemaSurfaceElevated
import com.example.ui.theme.CinemaSurfaceVariant

@Composable
fun ScriptSyncPanel(
    project: ProjectEntity,
    slides: List<MediaSlideEntity>,
    onScriptChanged: (String) -> Unit,
    onVoiceUploaded: (fileName: String, durationSec: Float, uri: String?) -> Unit,
    onRemoveVoice: () -> Unit,
    onRunSync: (SyncMode) -> Unit,
    modifier: Modifier = Modifier
) {
    var scriptInput by remember(project.scriptText) { mutableStateOf(project.scriptText) }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "imported_voiceover.wav"
            // Assume 25s for user-selected voiceover
            onVoiceUploaded(name, 25.0f, uri.toString())
        }
    }

    val sentenceCount = remember(scriptInput) {
        if (scriptInput.isBlank()) 0
        else scriptInput.split(Regex("(?<=[.!?])\\s+")).count { it.isNotBlank() }
    }

    val wordCount = remember(scriptInput) {
        if (scriptInput.isBlank()) 0
        else scriptInput.split(Regex("\\s+")).count { it.isNotBlank() }
    }

    val estimatedSec = remember(wordCount) {
        (wordCount / 2.16f).toInt()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
        // Voice-Over Audio Upload Section
        Text(
            text = "1. Narration Voice-Over Audio",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        Surface(
            color = CinemaSurfaceVariant,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CinemaBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = if (project.voiceAudioFileName != null) CinemaCyan.copy(alpha = 0.2f) else CinemaBorder,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = if (project.voiceAudioFileName != null) CinemaCyan else Color.Gray,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    Column {
                        Text(
                            text = project.voiceAudioFileName ?: "No voiceover file uploaded",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (project.voiceAudioFileName != null) {
                                "${project.voiceAudioDurationSec.toInt()}s duration • Ready for sync"
                            } else {
                                "Tap Upload or use script word-count pace (~${estimatedSec}s)"
                            },
                            color = Color.Gray,
                            fontSize = 10.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (project.voiceAudioFileName != null) {
                        OutlinedButton(
                            onClick = onRemoveVoice,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("remove_voice_btn")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                        }
                    }

                    Button(
                        onClick = { audioPicker.launch("audio/*") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CinemaAmberGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("upload_audio_btn")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text(if (project.voiceAudioFileName != null) "Replace" else "Upload Audio", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Full Script Input Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "2. Documentary Script Input",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = "$wordCount words • $sentenceCount sentences (~${estimatedSec}s)",
                color = CinemaCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = scriptInput,
            onValueChange = {
                scriptInput = it
                onScriptChanged(it)
            },
            placeholder = {
                Text(
                    text = "Paste or type complete documentary script here...\nSentence punctuation (. ! ?) will automatically align visual slides.",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CinemaBackground,
                unfocusedContainerColor = CinemaBackground,
                focusedBorderColor = CinemaAmberGold,
                unfocusedBorderColor = CinemaBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.LightGray
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .testTag("script_input_field"),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Automatic Synchronization Section
        Text(
            text = "3. Automatic Synchronization",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Text(
            text = "Synchronize ${slides.size} image slides with narration voice and script",
            color = Color.Gray,
            fontSize = 10.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Sequential Sync Card
            Surface(
                color = if (project.syncMode == SyncMode.SEQUENTIAL.name) CinemaSurfaceElevated else CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (project.syncMode == SyncMode.SEQUENTIAL.name) CinemaAmberGold else CinemaBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onRunSync(SyncMode.SEQUENTIAL) }
                    .testTag("sync_mode_sequential_btn")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, tint = CinemaAmberGold, modifier = Modifier.size(16.dp))
                        Text("Sequential Sync", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Divides total voiceover evenly (${if (slides.isNotEmpty()) (project.voiceAudioDurationSec / slides.size).toInt() else 5}s each).",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                }
            }

            // Smart AI Sync Card
            Surface(
                color = if (project.syncMode == SyncMode.SMART_AI.name) CinemaSurfaceElevated else CinemaSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (project.syncMode == SyncMode.SMART_AI.name) CinemaCyan else CinemaBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onRunSync(SyncMode.SMART_AI) }
                    .testTag("sync_mode_smart_ai_btn")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CinemaCyan, modifier = Modifier.size(16.dp))
                        Text("Smart AI Sync", color = CinemaCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Aligns slides on semantic sentence pauses and punctuation beats.",
                        color = Color.LightGray,
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )
                }
            }
        }
    }
}
