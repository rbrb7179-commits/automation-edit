package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.MediaSlideEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaSlideDao {
    @Query("SELECT * FROM media_slides WHERE projectId = :projectId ORDER BY serialOrder ASC")
    fun getSlidesForProject(projectId: Long): Flow<List<MediaSlideEntity>>

    @Query("SELECT * FROM media_slides WHERE projectId = :projectId ORDER BY serialOrder ASC")
    suspend fun getSlidesForProjectOnce(projectId: Long): List<MediaSlideEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlide(slide: MediaSlideEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlides(slides: List<MediaSlideEntity>): List<Long>

    @Update
    suspend fun updateSlide(slide: MediaSlideEntity)

    @Update
    suspend fun updateSlides(slides: List<MediaSlideEntity>)

    @Delete
    suspend fun deleteSlide(slide: MediaSlideEntity)

    @Query("DELETE FROM media_slides WHERE projectId = :projectId")
    suspend fun deleteSlidesForProject(projectId: Long)

    @Query("SELECT * FROM media_slides WHERE id = :slideId LIMIT 1")
    suspend fun getSlideById(slideId: Long): MediaSlideEntity?

    @Query("UPDATE media_slides SET imageUri = :newUri, title = :newTitle WHERE id = :slideId")
    suspend fun updateSlideImage(slideId: Long, newUri: String, newTitle: String)

    @Query("DELETE FROM media_slides WHERE id = :slideId")
    suspend fun deleteSlideById(slideId: Long)

    suspend fun replaceImage(slideId: Long, newUri: String, newTitle: String? = null) {
        val current = getSlideById(slideId) ?: return
        val title = newTitle ?: current.title
        updateSlide(current.copy(imageUri = newUri, title = title))
    }
}
