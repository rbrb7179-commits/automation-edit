package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val aspectRatio: String = AspectRatioType.LANDSCAPE_16_9.name,
    val resolution: String = ResolutionType.RES_1080P.name,
    val frameRate: String = FrameRateType.FPS_24.name,
    val codec: String = VideoCodecType.CODEC_H264.name,
    val syncMode: String = SyncMode.SMART_AI.name,
    val scriptText: String = "",
    val voiceAudioUri: String? = null,
    val voiceAudioDurationSec: Float = 30f,
    val voiceAudioFileName: String? = null,
    val voiceAudioFileSize: Long = 0L,
    val bgmPresetId: String = "cinematic_drone",
    val bgmVolume: Float = 0.35f,
    val voiceVolume: Float = 1.0f,
    val duckingEnabled: Boolean = true,
    val colorGradingPreset: String = ColorGradingPreset.WARM_DOCUMENTARY.name,
    val gradingIntensity: Float = 0.85f,
    val autoCaptionsEnabled: Boolean = true,
    val captionStyle: String = CaptionStyle.CINEMATIC_GOLD.name,
    val captionPosition: String = CaptionPosition.BOTTOM.name,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
