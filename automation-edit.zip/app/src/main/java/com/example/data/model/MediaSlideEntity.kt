package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "media_slides",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["projectId", "serialOrder"])]
)
data class MediaSlideEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val projectId: Long,
    val serialOrder: Int,
    val imageUri: String,
    val title: String = "",
    val durationSeconds: Float = 5.0f,
    val kenBurnsMotion: String = KenBurnsMotion.SLOW_ZOOM_IN.name,
    val captionSnippet: String = "",
    val soundEffectCue: String? = null,
    val focalPointX: Float = 0.5f,
    val focalPointY: Float = 0.5f,
    val startTimeSec: Float = 0f,
    val endTimeSec: Float = 5f,
    val syncConfidenceScore: Float? = null,
    val matchReason: String? = null,
    val visualTags: String? = null
)
