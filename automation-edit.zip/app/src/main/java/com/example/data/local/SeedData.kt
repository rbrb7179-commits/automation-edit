package com.example.data.local

import com.example.data.model.AspectRatioType
import com.example.data.model.CaptionPosition
import com.example.data.model.CaptionStyle
import com.example.data.model.ColorGradingPreset
import com.example.data.model.FrameRateType
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ResolutionType
import com.example.data.model.SyncMode
import com.example.data.model.VideoCodecType

object SeedData {
    suspend fun populateIfEmpty(db: AppDatabase) {
        val count = db.projectDao().getCount()
        if (count > 0) return

        // Project 1: The Deep Ocean Abyss (16:9 Long Video)
        val project1 = ProjectEntity(
            title = "The Deep Ocean Abyss: Unexplored Earth",
            description = "A visual exploration into the Mariana Trench and hydrothermal vent ecosystems.",
            aspectRatio = AspectRatioType.LANDSCAPE_16_9.name,
            resolution = ResolutionType.RES_1080P.name,
            frameRate = FrameRateType.FPS_24.name,
            codec = VideoCodecType.CODEC_H264.name,
            syncMode = SyncMode.SMART_AI.name,
            scriptText = "More than eighty percent of our planet's oceans remain completely unmapped. Beneath the twilight zone lies a world under crushing hydrostatic pressure. Here, hydrothermal chimneys spew superheated minerals into the pitch black abyss. In this extreme frontier, bizarre bioluminescent creatures illuminate the dark ocean floor.",
            voiceAudioUri = "asset://audio/ocean_voiceover_sample.mp3",
            voiceAudioDurationSec = 24.0f,
            voiceAudioFileName = "narration_deep_ocean_master.wav",
            bgmPresetId = "cinematic_drone",
            bgmVolume = 0.35f,
            voiceVolume = 1.0f,
            duckingEnabled = true,
            colorGradingPreset = ColorGradingPreset.TEAL_AND_ORANGE.name,
            gradingIntensity = 0.85f,
            autoCaptionsEnabled = true,
            captionStyle = CaptionStyle.CINEMATIC_GOLD.name,
            captionPosition = CaptionPosition.BOTTOM.name
        )
        val p1Id = db.projectDao().insertProject(project1)

        val slides1 = listOf(
            MediaSlideEntity(
                projectId = p1Id,
                serialOrder = 1,
                imageUri = "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&q=80",
                title = "Endless Blue Horizon",
                durationSeconds = 6.0f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                captionSnippet = "More than eighty percent of our planet's oceans remain completely unmapped.",
                soundEffectCue = "whoosh_cinematic"
            ),
            MediaSlideEntity(
                projectId = p1Id,
                serialOrder = 2,
                imageUri = "https://images.unsplash.com/photo-1682687220063-4742bd7fd538?w=800&q=80",
                title = "Descent to Twilight Zone",
                durationSeconds = 6.0f,
                kenBurnsMotion = KenBurnsMotion.PAN_LEFT_TO_RIGHT.name,
                captionSnippet = "Beneath the twilight zone lies a world under crushing hydrostatic pressure.",
                soundEffectCue = "deep_thud"
            ),
            MediaSlideEntity(
                projectId = p1Id,
                serialOrder = 3,
                imageUri = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
                title = "Hydrothermal Geothermal Vents",
                durationSeconds = 6.0f,
                kenBurnsMotion = KenBurnsMotion.DRAMATIC_PUSH.name,
                captionSnippet = "Here, hydrothermal chimneys spew superheated minerals into the pitch black abyss.",
                soundEffectCue = null
            ),
            MediaSlideEntity(
                projectId = p1Id,
                serialOrder = 4,
                imageUri = "https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?w=800&q=80",
                title = "Bioluminescent Abyss Life",
                durationSeconds = 6.0f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_OUT.name,
                captionSnippet = "In this extreme frontier, bizarre bioluminescent creatures illuminate the dark ocean floor.",
                soundEffectCue = "tape_rewind"
            )
        )
        db.mediaSlideDao().insertSlides(slides1)

        // Project 2: YouTube Shorts - The Secret History of the Microchip (9:16 Shorts)
        val project2 = ProjectEntity(
            title = "How 1cm of Silicon Changed Humanity",
            description = "High-energy fast-paced historical breakdown built for YouTube Shorts.",
            aspectRatio = AspectRatioType.SHORTS_9_16.name,
            resolution = ResolutionType.RES_1080P.name,
            frameRate = FrameRateType.FPS_60.name,
            codec = VideoCodecType.CODEC_H264.name,
            syncMode = SyncMode.SEQUENTIAL.name,
            scriptText = "In 1958, an engineer made a discovery on a single sliver of silicon. Today, over one trillion transistors fit in your pocket. This microscopic architecture powers our civilization.",
            voiceAudioUri = "asset://audio/silicon_shorts_voice.mp3",
            voiceAudioDurationSec = 15.0f,
            voiceAudioFileName = "voice_microchip_shorts.wav",
            bgmPresetId = "investigative_pulse",
            bgmVolume = 0.40f,
            voiceVolume = 1.0f,
            duckingEnabled = true,
            colorGradingPreset = ColorGradingPreset.WARM_DOCUMENTARY.name,
            gradingIntensity = 0.90f,
            autoCaptionsEnabled = true,
            captionStyle = CaptionStyle.BOLD_KARAOKE.name,
            captionPosition = CaptionPosition.MIDDLE.name
        )
        val p2Id = db.projectDao().insertProject(project2)

        val slides2 = listOf(
            MediaSlideEntity(
                projectId = p2Id,
                serialOrder = 1,
                imageUri = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80",
                title = "Silicon Wafer Core",
                durationSeconds = 5.0f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                captionSnippet = "In 1958, an engineer made a discovery on a single sliver of silicon.",
                soundEffectCue = "camera_shutter"
            ),
            MediaSlideEntity(
                projectId = p2Id,
                serialOrder = 2,
                imageUri = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80",
                title = "Microscopic Circuits",
                durationSeconds = 5.0f,
                kenBurnsMotion = KenBurnsMotion.PAN_RIGHT_TO_LEFT.name,
                captionSnippet = "Today, over one trillion transistors fit in your pocket.",
                soundEffectCue = "whoosh_cinematic"
            ),
            MediaSlideEntity(
                projectId = p2Id,
                serialOrder = 3,
                imageUri = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80",
                title = "Global Network Architecture",
                durationSeconds = 5.0f,
                kenBurnsMotion = KenBurnsMotion.DRAMATIC_PUSH.name,
                captionSnippet = "This microscopic architecture powers our civilization.",
                soundEffectCue = "deep_thud"
            )
        )
        db.mediaSlideDao().insertSlides(slides2)

        // Project 3: Ancient Whispers (Cinematic 4K 16:9)
        val project3 = ProjectEntity(
            title = "Ancient Whispers: Lost Desert Civilizations",
            description = "Archival cinematography examining forgotten stone monuments.",
            aspectRatio = AspectRatioType.LANDSCAPE_16_9.name,
            resolution = ResolutionType.RES_4K.name,
            frameRate = FrameRateType.FPS_24.name,
            codec = VideoCodecType.CODEC_HEVC_H265.name,
            syncMode = SyncMode.SMART_AI.name,
            scriptText = "Across the arid expanses of North Africa, giant stone fortresses slowly surrendered to shifting sands. Archaeologists now deploy satellite lidar to uncover what once flourished here.",
            voiceAudioUri = null,
            voiceAudioDurationSec = 16.0f,
            voiceAudioFileName = null,
            bgmPresetId = "historical_strings",
            bgmVolume = 0.30f,
            voiceVolume = 1.0f,
            duckingEnabled = true,
            colorGradingPreset = ColorGradingPreset.CINEMATIC_NOIR.name,
            gradingIntensity = 1.0f,
            autoCaptionsEnabled = true,
            captionStyle = CaptionStyle.MINIMAL_BOX.name,
            captionPosition = CaptionPosition.BOTTOM.name
        )
        val p3Id = db.projectDao().insertProject(project3)

        val slides3 = listOf(
            MediaSlideEntity(
                projectId = p3Id,
                serialOrder = 1,
                imageUri = "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&q=80",
                title = "Shifting Desert Dunes",
                durationSeconds = 8.0f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                captionSnippet = "Across the arid expanses of North Africa, giant stone fortresses slowly surrendered to shifting sands.",
                soundEffectCue = "whoosh_cinematic"
            ),
            MediaSlideEntity(
                projectId = p3Id,
                serialOrder = 2,
                imageUri = "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&q=80",
                title = "Stone Fortress Ruins",
                durationSeconds = 8.0f,
                kenBurnsMotion = KenBurnsMotion.PAN_LEFT_TO_RIGHT.name,
                captionSnippet = "Archaeologists now deploy satellite lidar to uncover what once flourished here.",
                soundEffectCue = "deep_thud"
            )
        )
        db.mediaSlideDao().insertSlides(slides3)
    }
}
