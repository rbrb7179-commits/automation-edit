package com.example.data.media

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log

data class AudioFileInfo(
    val uriString: String,
    val fileName: String,
    val durationSec: Float,
    val fileSizeBytes: Long,
    val mimeType: String?
)

data class ImageFileInfo(
    val uriString: String,
    val fileName: String,
    val fileSizeBytes: Long
)

object MediaHelper {
    private const val TAG = "MediaHelper"

    /**
     * Attempts to take persistable URI permission so the app can read the media
     * across app reboots or project reopening.
     */
    fun takePersistableUriPermissionSafe(context: Context, uri: Uri) {
        try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (e: Exception) {
            // Some URIs (e.g. from photo picker or action send) may not support persistable permissions.
            Log.w(TAG, "Could not take persistable URI permission for $uri: ${e.message}")
        }
    }

    /**
     * Extracts filename and size from ContentResolver OpenableColumns.
     */
    fun getFileNameAndSize(context: Context, uri: Uri): Pair<String, Long> {
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) {
                        name = cursor.getString(nameIndex) ?: name
                    }
                    if (sizeIndex != -1) {
                        size = cursor.getLong(sizeIndex)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error querying uri metadata for $uri: ${e.message}")
            name = uri.lastPathSegment?.substringAfterLast('/') ?: name
        }
        return Pair(name, size)
    }

    /**
     * Extracts audio metadata (exact duration in seconds, file name, and file size)
     * using MediaMetadataRetriever and ContentResolver.
     */
    fun extractAudioInfo(context: Context, uri: Uri): AudioFileInfo {
        val (fileName, fileSize) = getFileNameAndSize(context, uri)
        val mimeType = context.contentResolver.getType(uri)
        var durationSec = 15.0f // sensible fallback

        val retriever = MediaMetadataRetriever()
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                retriever.setDataSource(pfd.fileDescriptor)
                val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                if (durationStr != null) {
                    val durationMs = durationStr.toLongOrNull() ?: 0L
                    if (durationMs > 0) {
                        durationSec = durationMs / 1000.0f
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not extract duration with retriever for $uri: ${e.message}")
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        return AudioFileInfo(
            uriString = uri.toString(),
            fileName = fileName,
            durationSec = durationSec,
            fileSizeBytes = fileSize,
            mimeType = mimeType
        )
    }

    /**
     * Formats bytes to readable human string (e.g. "3.4 MB", "512 KB").
     */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "Unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format("%.1f MB", mb)
            kb >= 1.0 -> String.format("%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    /**
     * Formats seconds into MM:SS format.
     */
    fun formatDuration(seconds: Float): String {
        val totalSec = seconds.toInt().coerceAtLeast(0)
        val mins = totalSec / 60
        val secs = totalSec % 60
        return String.format("%02d:%02d", mins, secs)
    }

    /**
     * Reads text content from a text file URI.
     */
    fun readTextFromUri(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                inputStream.bufferedReader().use { it.readText() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading text from $uri: ${e.message}")
            null
        }
    }

    /**
     * Efficiently decodes and downsamples a bitmap from URI for rendering.
     */
    fun loadBitmapFromUri(context: Context, uri: Uri, targetWidth: Int, targetHeight: Int): android.graphics.Bitmap? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val options = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                android.graphics.BitmapFactory.decodeStream(stream, null, options)

                var sampleSize = 1
                while (options.outWidth / (sampleSize * 2) >= targetWidth && options.outHeight / (sampleSize * 2) >= targetHeight) {
                    sampleSize *= 2
                }

                context.contentResolver.openInputStream(uri)?.use { secondStream ->
                    val decodeOptions = android.graphics.BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                    }
                    android.graphics.BitmapFactory.decodeStream(secondStream, null, decodeOptions)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load bitmap from uri $uri", e)
            null
        }
    }
}
