package com.example.data.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class RealAudioPlayerState(
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isPrepared: Boolean = false,
    val currentUri: String? = null,
    val errorMessage: String? = null
)

class AudioPlaybackManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "AudioPlaybackManager"
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _state = MutableStateFlow(RealAudioPlayerState())
    val state: StateFlow<RealAudioPlayerState> = _state.asStateFlow()

    fun loadAudio(uriString: String) {
        if (_state.value.currentUri == uriString && _state.value.isPrepared) {
            return
        }

        stop()
        _state.value = RealAudioPlayerState(currentUri = uriString, isPrepared = false)

        try {
            val uri = Uri.parse(uriString)
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )

                if (uriString.startsWith("content://") || uriString.startsWith("file://")) {
                    context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        setDataSource(pfd.fileDescriptor)
                    } ?: setDataSource(context, uri)
                } else if (uriString.startsWith("http://") || uriString.startsWith("https://")) {
                    setDataSource(uriString)
                } else {
                    // Try context URI
                    setDataSource(context, uri)
                }

                setOnPreparedListener { mp ->
                    val dur = mp.duration.toLong().coerceAtLeast(0L)
                    _state.value = _state.value.copy(
                        isPrepared = true,
                        durationMs = dur,
                        currentPositionMs = 0L,
                        errorMessage = null
                    )
                }

                setOnCompletionListener {
                    pause()
                    _state.value = _state.value.copy(
                        isPlaying = false,
                        currentPositionMs = 0L
                    )
                }

                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                    _state.value = _state.value.copy(
                        isPlaying = false,
                        isPrepared = false,
                        errorMessage = "Audio playback error ($what, $extra)"
                    )
                    true
                }

                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load audio from $uriString", e)
            _state.value = _state.value.copy(
                isPrepared = false,
                errorMessage = "Could not open audio file: ${e.message}"
            )
        }
    }

    fun play() {
        val player = mediaPlayer ?: return
        if (!_state.value.isPrepared) return

        try {
            player.start()
            _state.value = _state.value.copy(isPlaying = true)
            startProgressLoop()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting playback", e)
        }
    }

    fun pause() {
        progressJob?.cancel()
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing playback", e)
        }
        _state.value = _state.value.copy(isPlaying = false)
    }

    fun togglePlayPause() {
        if (_state.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun seekTo(positionMs: Long) {
        val player = mediaPlayer ?: return
        if (!_state.value.isPrepared) return

        val clamped = positionMs.coerceIn(0L, _state.value.durationMs)
        try {
            player.seekTo(clamped.toInt())
            _state.value = _state.value.copy(currentPositionMs = clamped)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking", e)
        }
    }

    fun stop() {
        progressJob?.cancel()
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.reset()
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping", e)
        }
        mediaPlayer = null
        _state.value = RealAudioPlayerState()
    }

    private fun startProgressLoop() {
        progressJob?.cancel()
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive && _state.value.isPlaying) {
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _state.value = _state.value.copy(
                                currentPositionMs = player.currentPosition.toLong()
                            )
                        }
                    } catch (_: Exception) {}
                }
                delay(100)
            }
        }
    }

    fun release() {
        stop()
    }
}
