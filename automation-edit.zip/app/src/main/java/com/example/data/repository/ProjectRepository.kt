package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SyncMode
import com.example.integration.GeminiAiSyncEngine
import com.example.integration.GeminiAiSyncEngineImpl
import com.example.integration.SpeechRecognitionBridge
import com.example.integration.SpeechRecognitionBridgeImpl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ProjectRepository(
    private val db: AppDatabase,
    private val speechEngine: SpeechRecognitionBridge = SpeechRecognitionBridgeImpl(),
    private val geminiEngine: GeminiAiSyncEngine = GeminiAiSyncEngineImpl()
) {

    val allProjects: Flow<List<ProjectEntity>> = db.projectDao().getAllProjects()

    fun getProject(id: Long): Flow<ProjectEntity?> = db.projectDao().getProjectById(id)

    fun getSlides(projectId: Long): Flow<List<MediaSlideEntity>> =
        db.mediaSlideDao().getSlidesForProject(projectId)

    suspend fun createProject(project: ProjectEntity): Long = withContext(Dispatchers.IO) {
        db.projectDao().insertProject(project)
    }

    suspend fun updateProject(project: ProjectEntity) = withContext(Dispatchers.IO) {
        db.projectDao().updateProject(project.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteProject(projectId: Long) = withContext(Dispatchers.IO) {
        db.mediaSlideDao().deleteSlidesForProject(projectId)
        db.projectDao().deleteProjectById(projectId)
    }

    suspend fun addSlide(slide: MediaSlideEntity): Long = withContext(Dispatchers.IO) {
        val existing = db.mediaSlideDao().getSlidesForProjectOnce(slide.projectId)
        val nextOrder = if (existing.isEmpty()) 1 else (existing.maxOf { it.serialOrder } + 1)
        val startSec = if (existing.isNotEmpty()) existing.sumOf { it.durationSeconds.toDouble() }.toFloat() else 0f
        val newSlide = slide.copy(
            serialOrder = nextOrder,
            startTimeSec = startSec,
            endTimeSec = startSec + slide.durationSeconds
        )
        db.mediaSlideDao().insertSlide(newSlide)
    }

    suspend fun addMultipleSlides(projectId: Long, items: List<Pair<String, String>>) = withContext(Dispatchers.IO) {
        val existing = db.mediaSlideDao().getSlidesForProjectOnce(projectId)
        var startOrder = if (existing.isEmpty()) 1 else (existing.maxOf { it.serialOrder } + 1)
        var currentOffsetSec = if (existing.isNotEmpty()) existing.sumOf { it.durationSeconds.toDouble() }.toFloat() else 0f

        val newSlides = items.map { (uri, title) ->
            val slide = MediaSlideEntity(
                projectId = projectId,
                serialOrder = startOrder++,
                imageUri = uri,
                title = title.ifBlank { "Slide #$startOrder" },
                durationSeconds = 5.0f,
                startTimeSec = currentOffsetSec,
                endTimeSec = currentOffsetSec + 5.0f,
                kenBurnsMotion = KenBurnsMotion.SLOW_ZOOM_IN.name,
                captionSnippet = ""
            )
            currentOffsetSec += 5.0f
            slide
        }
        db.mediaSlideDao().insertSlides(newSlides)
    }

    suspend fun replaceSlideImage(slideId: Long, newUri: String, newTitle: String? = null) = withContext(Dispatchers.IO) {
        db.mediaSlideDao().replaceImage(slideId, newUri, newTitle)
    }

    suspend fun updateSlide(slide: MediaSlideEntity) = withContext(Dispatchers.IO) {
        db.mediaSlideDao().updateSlide(slide)
    }

    suspend fun deleteSlide(slideId: Long, projectId: Long) = withContext(Dispatchers.IO) {
        db.mediaSlideDao().deleteSlideById(slideId)
        normalizeSlideTimelines(projectId)
    }

    suspend fun moveSlide(projectId: Long, fromIndex: Int, toIndex: Int) = withContext(Dispatchers.IO) {
        val list = db.mediaSlideDao().getSlidesForProjectOnce(projectId).toMutableList()
        if (fromIndex in list.indices && toIndex in list.indices && fromIndex != toIndex) {
            val item = list.removeAt(fromIndex)
            list.add(toIndex, item)
            var timeCursor = 0f
            val updated = list.mapIndexed { index, slide ->
                val start = timeCursor
                val end = start + slide.durationSeconds
                timeCursor = end
                slide.copy(
                    serialOrder = index + 1,
                    startTimeSec = start,
                    endTimeSec = end
                )
            }
            db.mediaSlideDao().updateSlides(updated)
        }
    }

    suspend fun swapSlides(projectId: Long, indexA: Int, indexB: Int) = withContext(Dispatchers.IO) {
        val list = db.mediaSlideDao().getSlidesForProjectOnce(projectId).toMutableList()
        if (indexA in list.indices && indexB in list.indices && indexA != indexB) {
            val temp = list[indexA]
            list[indexA] = list[indexB]
            list[indexB] = temp
            var timeCursor = 0f
            val updated = list.mapIndexed { index, slide ->
                val start = timeCursor
                val end = start + slide.durationSeconds
                timeCursor = end
                slide.copy(
                    serialOrder = index + 1,
                    startTimeSec = start,
                    endTimeSec = end
                )
            }
            db.mediaSlideDao().updateSlides(updated)
        }
    }

    suspend fun moveSlideToTop(projectId: Long, fromIndex: Int) = withContext(Dispatchers.IO) {
        moveSlide(projectId, fromIndex, 0)
    }

    suspend fun moveSlideToEnd(projectId: Long, fromIndex: Int) = withContext(Dispatchers.IO) {
        val list = db.mediaSlideDao().getSlidesForProjectOnce(projectId)
        if (list.isNotEmpty()) {
            moveSlide(projectId, fromIndex, list.size - 1)
        }
    }

    private suspend fun normalizeSlideTimelines(projectId: Long) = withContext(Dispatchers.IO) {
        val slides = db.mediaSlideDao().getSlidesForProjectOnce(projectId).sortedBy { it.serialOrder }
        var timeCursor = 0f
        val updated = slides.mapIndexed { index, slide ->
            val start = timeCursor
            val end = start + slide.durationSeconds
            timeCursor = end
            slide.copy(
                serialOrder = index + 1,
                startTimeSec = start,
                endTimeSec = end
            )
        }
        db.mediaSlideDao().updateSlides(updated)
    }

    /**
     * SEQUENTIAL SYNC:
     * - Preserves the exact uploaded image serial order (#1, #2, #3...).
     * - Matches script sentences with images sequentially.
     * - Calculates image durations using actual narration timestamps from audio alignment.
     * - Guarantees zero gaps: start of slide i+1 strictly equals end of slide i.
     * - Preserves total original audio duration.
     * - Never reorders images in this mode.
     */
    suspend fun executeSequentialSync(context: Context, projectId: Long): List<MediaSlideEntity> = withContext(Dispatchers.IO) {
        val project = db.projectDao().getProjectByIdOnce(projectId) ?: return@withContext emptyList()
        val slides = db.mediaSlideDao().getSlidesForProjectOnce(projectId).sortedBy { it.serialOrder }
        if (slides.isEmpty()) return@withContext emptyList()

        // 1. Generate accurate sentence timestamps from audio/script
        val alignment = speechEngine.alignVoiceover(
            context = context,
            audioUriString = project.voiceAudioUri,
            referenceScript = project.scriptText
        )

        val sentences = alignment.sentences
        val totalAudioSec = alignment.totalDurationMs / 1000f

        // 2. Distribute durations across slides sequentially without reordering
        var timeCursorSec = 0f
        val updatedSlides = mutableListOf<MediaSlideEntity>()

        for (i in slides.indices) {
            val slide = slides[i]
            val isLast = (i == slides.size - 1)

            val sentence = if (i < sentences.size) sentences[i] else null
            val calculatedDurationSec = if (sentence != null) {
                ((sentence.endMs - sentence.startMs) / 1000f).coerceAtLeast(1.5f)
            } else {
                // If more slides than sentences, split remaining time
                val remainingTime = (totalAudioSec - timeCursorSec).coerceAtLeast(2.0f)
                val remainingSlides = (slides.size - i).coerceAtLeast(1)
                (remainingTime / remainingSlides).coerceAtLeast(2.0f)
            }

            val startSec = timeCursorSec
            val endSec = if (isLast) {
                // Guarantee exact audio length preservation without drift
                totalAudioSec.coerceAtLeast(startSec + 1.0f)
            } else {
                startSec + calculatedDurationSec
            }
            val finalDuration = ((endSec - startSec) * 10).toInt() / 10f

            timeCursorSec = endSec

            val caption = sentence?.text ?: slide.captionSnippet

            updatedSlides.add(
                slide.copy(
                    serialOrder = i + 1,
                    durationSeconds = finalDuration,
                    startTimeSec = ((startSec * 10).toInt() / 10f),
                    endTimeSec = ((endSec * 10).toInt() / 10f),
                    captionSnippet = caption,
                    syncConfidenceScore = 1.0f,
                    matchReason = "Sequential upload order (#${i + 1}) matching voice narration cadence"
                )
            )
        }

        db.mediaSlideDao().updateSlides(updatedSlides)
        db.projectDao().updateProject(
            project.copy(
                syncMode = SyncMode.SEQUENTIAL.name,
                voiceAudioDurationSec = totalAudioSec,
                updatedAt = System.currentTimeMillis()
            )
        )

        updatedSlides
    }

    /**
     * SMART AI SYNC:
     * - Matches images with narration based on visual-semantic meaning.
     * - Provides matching confidence scores [0.0 - 1.0] and reasoning.
     * - Maps each sentence scene to the best visual slide image.
     * - Sets non-overlapping start/end timestamps with zero gaps.
     * - Preserves total original audio duration.
     * - Enables manual corrections.
     */
    suspend fun executeSmartAiSync(
        context: Context,
        projectId: Long
    ): Pair<List<MediaSlideEntity>, GeminiAiSyncEngine.AiSyncResult> = withContext(Dispatchers.IO) {
        val project = db.projectDao().getProjectByIdOnce(projectId) ?: return@withContext Pair(emptyList(), GeminiAiSyncEngine.AiSyncResult(emptyList(), "", false, "Project not found"))
        val slides = db.mediaSlideDao().getSlidesForProjectOnce(projectId).sortedBy { it.serialOrder }
        if (slides.isEmpty()) return@withContext Pair(emptyList(), GeminiAiSyncEngine.AiSyncResult(emptyList(), "", false, "No slides to synchronize"))

        // 1. Generate speech narration sentence timestamps
        val alignment = speechEngine.alignVoiceover(
            context = context,
            audioUriString = project.voiceAudioUri,
            referenceScript = project.scriptText
        )

        val sentences = alignment.sentences
        val totalAudioSec = alignment.totalDurationMs / 1000f

        // 2. Multimodal AI Analysis with Gemini 3.8 Flash / Semantic Engine
        val aiResult = geminiEngine.analyzeAndAlign(
            context = context,
            project = project,
            slides = slides,
            sentences = sentences
        )

        // 3. Reorder/match slides to narrative scenes based on AI matches
        val slideBySerial = slides.associateBy { it.serialOrder }.toMutableMap()
        val updatedSlides = mutableListOf<MediaSlideEntity>()

        var timeCursorSec = 0f
        val usedSerials = mutableSetOf<Int>()

        aiResult.matches.forEachIndexed { sceneIdx, match ->
            val matchedSlide = slideBySerial[match.matchedSlideSerialOrder]
                ?: slides.firstOrNull { it.serialOrder !in usedSerials }
                ?: slides[sceneIdx % slides.size]

            usedSerials.add(matchedSlide.serialOrder)

            val sentence = sentences.getOrNull(sceneIdx)
            val sceneDuration = if (sentence != null) {
                ((sentence.endMs - sentence.startMs) / 1000f).coerceAtLeast(1.5f)
            } else {
                (totalAudioSec / aiResult.matches.size.coerceAtLeast(1)).coerceAtLeast(2.0f)
            }

            val startSec = timeCursorSec
            val endSec = startSec + sceneDuration
            timeCursorSec = endSec

            updatedSlides.add(
                matchedSlide.copy(
                    serialOrder = sceneIdx + 1,
                    durationSeconds = ((sceneDuration * 10).toInt() / 10f),
                    startTimeSec = ((startSec * 10).toInt() / 10f),
                    endTimeSec = ((endSec * 10).toInt() / 10f),
                    captionSnippet = match.sentenceText,
                    kenBurnsMotion = match.suggestedMotion.name,
                    syncConfidenceScore = match.confidenceScore,
                    matchReason = match.reasoning
                )
            )
        }

        // Include any remaining slides not mapped to early scenes
        val remainingSlides = slides.filter { it.serialOrder !in usedSerials }
        remainingSlides.forEachIndexed { remIdx, slide ->
            val order = updatedSlides.size + 1
            val dur = 4.0f
            val startSec = timeCursorSec
            val endSec = startSec + dur
            timeCursorSec = endSec

            updatedSlides.add(
                slide.copy(
                    serialOrder = order,
                    durationSeconds = dur,
                    startTimeSec = ((startSec * 10).toInt() / 10f),
                    endTimeSec = ((endSec * 10).toInt() / 10f),
                    syncConfidenceScore = 0.75f,
                    matchReason = "Supplementary scene visual"
                )
            )
        }

        // Guarantee final slide aligns with exact total audio duration
        if (updatedSlides.isNotEmpty() && totalAudioSec > 0f) {
            val lastIdx = updatedSlides.size - 1
            val lastSlide = updatedSlides[lastIdx]
            val lastStart = lastSlide.startTimeSec
            val finalEnd = totalAudioSec.coerceAtLeast(lastStart + 1.0f)
            val finalDur = ((finalEnd - lastStart) * 10).toInt() / 10f
            updatedSlides[lastIdx] = lastSlide.copy(
                endTimeSec = ((finalEnd * 10).toInt() / 10f),
                durationSeconds = finalDur
            )
        }

        db.mediaSlideDao().updateSlides(updatedSlides)
        db.projectDao().updateProject(
            project.copy(
                syncMode = SyncMode.SMART_AI.name,
                voiceAudioDurationSec = totalAudioSec,
                updatedAt = System.currentTimeMillis()
            )
        )

        Pair(updatedSlides, aiResult)
    }

    /**
     * Manual Correction: swap the image content and title between two matched scenes
     * while preserving the synchronized narration duration, timestamps, and captions.
     */
    suspend fun manualSwapSceneImages(projectId: Long, slideIdA: Long, slideIdB: Long) = withContext(Dispatchers.IO) {
        val slideA = db.mediaSlideDao().getSlideById(slideIdA) ?: return@withContext
        val slideB = db.mediaSlideDao().getSlideById(slideIdB) ?: return@withContext

        // Swap images and titles, but retain timestamps and scene captions
        val updatedA = slideA.copy(
            imageUri = slideB.imageUri,
            title = slideB.title,
            matchReason = "Manually assigned by editor (swapped with Scene #${slideB.serialOrder})",
            syncConfidenceScore = 1.0f
        )
        val updatedB = slideB.copy(
            imageUri = slideA.imageUri,
            title = slideA.title,
            matchReason = "Manually assigned by editor (swapped with Scene #${slideA.serialOrder})",
            syncConfidenceScore = 1.0f
        )

        db.mediaSlideDao().updateSlide(updatedA)
        db.mediaSlideDao().updateSlide(updatedB)
    }

    suspend fun autoSyncTimeline(projectId: Long, mode: SyncMode, context: Context? = null) = withContext(Dispatchers.IO) {
        if (context != null) {
            when (mode) {
                SyncMode.SEQUENTIAL -> executeSequentialSync(context, projectId)
                SyncMode.SMART_AI -> executeSmartAiSync(context, projectId)
            }
        }
    }
}
