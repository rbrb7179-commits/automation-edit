package com.example.data.model

enum class AspectRatioType(val label: String, val ratio: Float, val dimensionLabel: String) {
    LANDSCAPE_16_9("16:9 Long Video", 16f / 9f, "1920x1080 / 3840x2160"),
    SHORTS_9_16("9:16 YouTube Shorts / Reels", 9f / 16f, "1080x1920 / 2160x3840"),
    SQUARE_1_1("1:1 Social Square", 1f, "1080x1080")
}

enum class ResolutionType(val label: String, val width169: Int, val height169: Int) {
    RES_1080P("1080p FHD (Recommended)", 1920, 1080),
    RES_4K("4K Ultra HD (Cinematic)", 3840, 2160),
    RES_720P("720p HD (Draft Speed)", 1280, 720)
}

enum class FrameRateType(val label: String, val fps: Int) {
    FPS_24("24 fps (Cinematic Film Standard)", 24),
    FPS_30("30 fps (Web & Broadcast)", 30),
    FPS_60("60 fps (Ultra Smooth Motion)", 60)
}

enum class VideoCodecType(val label: String, val ffmpegCodec: String) {
    CODEC_H264("H.264 (Universal Compatibility)", "libx264"),
    CODEC_HEVC_H265("H.265 / HEVC (High Efficiency)", "libx265")
}

enum class KenBurnsMotion(
    val label: String,
    val description: String,
    val iconName: String
) {
    SLOW_ZOOM_IN("Slow Zoom In", "Gradually pushes toward focal subject for dramatic tension", "zoom_in"),
    SLOW_ZOOM_OUT("Slow Zoom Out", "Pulls out to reveal broader documentary context", "zoom_out"),
    PAN_LEFT_TO_RIGHT("Pan Left → Right", "Horizontal sweep from historical record left to right", "arrow_forward"),
    PAN_RIGHT_TO_LEFT("Pan Right → Left", "Sweeping camera tracking across scene elements", "arrow_back"),
    DRAMATIC_PUSH("Dramatic Push", "Faster dynamic scale emphasizing climactic revelation", "speed"),
    STATIC_LOCKED("Static Locked", "Still archival presentation with zero drift", "crop_free")
}

enum class SyncMode(
    val title: String,
    val subtitle: String,
    val details: String
) {
    SEQUENTIAL(
        title = "Sequential Sync",
        subtitle = "Linear timeline distribution",
        details = "Divides total voice-over duration evenly across all imported image slides with smooth cross-dissolves."
    ),
    SMART_AI(
        title = "Smart AI Sync",
        subtitle = "Semantic voice & script alignment",
        details = "Analyzes transcript pauses, punctuation, and sentence changes with Gemini AI to cut slides precisely on keyword beats."
    )
}

enum class ColorGradingPreset(
    val title: String,
    val description: String,
    val primaryToneHex: Long,
    val contrast: Float,
    val saturation: Float,
    val brightness: Float,
    val warmCoolBalance: Float // -1 (cool) to +1 (warm)
) {
    CLEAN_NATURAL(
        title = "Natural / Standard",
        description = "Neutral documentary color without tint",
        primaryToneHex = 0xFF64748B,
        contrast = 1.0f,
        saturation = 1.0f,
        brightness = 0.0f,
        warmCoolBalance = 0.0f
    ),
    WARM_DOCUMENTARY(
        title = "Warm Archival",
        description = "Gentle sepia amber warmth ideal for historical sagas",
        primaryToneHex = 0xFFF59E0B,
        contrast = 1.15f,
        saturation = 0.95f,
        brightness = 0.02f,
        warmCoolBalance = 0.4f
    ),
    CINEMATIC_NOIR(
        title = "Film Noir (B&W)",
        description = "High-contrast monochrome with deep dramatic shadows",
        primaryToneHex = 0xFFE2E8F0,
        contrast = 1.35f,
        saturation = 0.0f,
        brightness = -0.05f,
        warmCoolBalance = 0.0f
    ),
    VINTAGE_70S(
        title = "Vintage 1970s",
        description = "Faded cyan-tinted nostalgic documentary film stock",
        primaryToneHex = 0xFFEAB308,
        contrast = 1.1f,
        saturation = 0.85f,
        brightness = 0.04f,
        warmCoolBalance = 0.25f
    ),
    TEAL_AND_ORANGE(
        title = "Teal & Orange",
        description = "Modern blockbuster Hollywood documentary look",
        primaryToneHex = 0xFF06B6D4,
        contrast = 1.25f,
        saturation = 1.2f,
        brightness = -0.02f,
        warmCoolBalance = -0.1f
    ),
    BLEACH_BYPASS(
        title = "Bleach Bypass",
        description = "Desaturated high contrast gritty military/investigative feel",
        primaryToneHex = 0xFF94A3B8,
        contrast = 1.4f,
        saturation = 0.6f,
        brightness = -0.04f,
        warmCoolBalance = -0.2f
    ),
    KODAK_FILM(
        title = "Kodak Chrome",
        description = "Vibrant organic tones with golden highlights and film character",
        primaryToneHex = 0xFFFB923C,
        contrast = 1.2f,
        saturation = 1.15f,
        brightness = 0.01f,
        warmCoolBalance = 0.2f
    )
}

enum class CaptionStyle(val title: String, val description: String) {
    CINEMATIC_GOLD("Cinematic Gold", "Amber gold text with soft dark drop-shadow"),
    MODERN_CLEAN("Clean Modern", "Crisp white sans-serif with subtle background pill"),
    BOLD_KARAOKE("Bold Shorts Hook", "Large bold yellow uppercase for high-energy Shorts"),
    MINIMAL_BOX("Box Subtitles", "Classic BBC/PBS documentary boxed subtitles")
}

enum class CaptionPosition(val title: String) {
    BOTTOM("Bottom Third"),
    MIDDLE("Center Screen"),
    TOP("Top Header")
}
