package com.example.data.model

data class BgmPreset(
    val id: String,
    val title: String,
    val genre: String,
    val mood: String,
    val durationLabel: String,
    val bpm: Int,
    val waveformSeed: Long
)

data class SoundEffectItem(
    val id: String,
    val name: String,
    val category: String,
    val durationMs: Long,
    val description: String,
    val icon: String
)

data class SubtitleCue(
    val id: String,
    val slideSerial: Int,
    val startTimeSec: Float,
    val endTimeSec: Float,
    val text: String
)

object AudioLibrary {
    val bgmPresets = listOf(
        BgmPreset(
            id = "cinematic_drone",
            title = "Deep Earth Atmosphere",
            genre = "Cinematic Ambient",
            mood = "Mysterious & Contemplative",
            durationLabel = "3:45",
            bpm = 65,
            waveformSeed = 101L
        ),
        BgmPreset(
            id = "historical_strings",
            title = "Remnants of History",
            genre = "Orchestral Strings",
            mood = "Reflective & Emotional",
            durationLabel = "4:12",
            bpm = 72,
            waveformSeed = 202L
        ),
        BgmPreset(
            id = "investigative_pulse",
            title = "Silent Archives",
            genre = "Minimal Synth Pulse",
            mood = "Intense & Inquisitive",
            durationLabel = "3:20",
            bpm = 88,
            waveformSeed = 303L
        ),
        BgmPreset(
            id = "epic_discovery",
            title = "Apex of Civilization",
            genre = "Cinematic Narrative",
            mood = "Awe-Inspiring & Grand",
            durationLabel = "4:30",
            bpm = 95,
            waveformSeed = 404L
        )
    )

    val soundEffects = listOf(
        SoundEffectItem(
            id = "whoosh_cinematic",
            name = "Cinematic Whoosh",
            category = "Transition",
            durationMs = 800,
            description = "Smooth air rush ideal for slide transitions",
            icon = "swap_horiz"
        ),
        SoundEffectItem(
            id = "camera_shutter",
            name = "Vintage Camera Shutter",
            category = "Focal",
            durationMs = 600,
            description = "Mechanical 35mm shutter snapshot for archival photo reveal",
            icon = "camera"
        ),
        SoundEffectItem(
            id = "deep_thud",
            name = "Sub Bass Impact",
            category = "Impact",
            durationMs = 1400,
            description = "Low-end documentary trailer hit on dramatic sentence",
            icon = "lens"
        ),
        SoundEffectItem(
            id = "tape_rewind",
            name = "Archival Tape Clack",
            category = "Historical",
            durationMs = 950,
            description = "Magnetic reel start click for historical documentary segments",
            icon = "audiotrack"
        ),
        SoundEffectItem(
            id = "riser_tension",
            name = "Tension Riser",
            category = "Suspense",
            durationMs = 2100,
            description = "Gradual pitch buildup leading into conclusion",
            icon = "trending_up"
        )
    )
}
