package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.NewProjectScreen
import com.example.ui.theme.CinemaBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ProjectViewModel

sealed class AppScreen {
    object Dashboard : AppScreen()
    object NewProject : AppScreen()
    data class Editor(val projectId: Long) : AppScreen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            com.example.integration.configureAppCheck(this, intent)
        } catch (e: Throwable) {
            // Guard against startup crash if optional services are not present
        }
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CinemaBackground
                ) {
                    val viewModel: ProjectViewModel = viewModel()
                    AutomationEditApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AutomationEditApp(viewModel: ProjectViewModel) {
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Dashboard) }

    val projects by viewModel.allProjects.collectAsStateWithLifecycle()
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val currentSlides by viewModel.currentSlides.collectAsStateWithLifecycle()
    val activeSlide by viewModel.activeSlide.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()

    when (val screen = currentScreen) {
        is AppScreen.Dashboard -> {
            DashboardScreen(
                projects = projects,
                onSelectProject = { id ->
                    viewModel.selectProject(id)
                    currentScreen = AppScreen.Editor(id)
                },
                onNavigateCreate = {
                    currentScreen = AppScreen.NewProject
                },
                onDeleteProject = { id ->
                    viewModel.selectProject(id)
                    viewModel.deleteCurrentProject()
                }
            )
        }
        is AppScreen.NewProject -> {
            NewProjectScreen(
                onNavigateBack = { currentScreen = AppScreen.Dashboard },
                onCreateProject = { title, desc, aspect, res, fps, codec ->
                    viewModel.createProject(title, desc, aspect, res, fps, codec)
                    currentScreen = AppScreen.Dashboard
                }
            )
        }
        is AppScreen.Editor -> {
            val project = currentProject
            if (project != null) {
                EditorScreen(
                    viewModel = viewModel,
                    project = project,
                    slides = currentSlides,
                    activeSlide = activeSlide,
                    playbackState = playbackState,
                    activeTab = activeTab,
                    onNavigateBack = { currentScreen = AppScreen.Dashboard }
                )
            } else {
                DashboardScreen(
                    projects = projects,
                    onSelectProject = { id ->
                        viewModel.selectProject(id)
                        currentScreen = AppScreen.Editor(id)
                    },
                    onNavigateCreate = { currentScreen = AppScreen.NewProject },
                    onDeleteProject = { id ->
                        viewModel.selectProject(id)
                        viewModel.deleteCurrentProject()
                    }
                )
            }
        }
    }
}
