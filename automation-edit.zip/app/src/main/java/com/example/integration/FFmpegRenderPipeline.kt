package com.example.integration

import com.example.data.model.AspectRatioType
import com.example.data.model.ColorGradingPreset
import com.example.data.model.KenBurnsMotion
import com.example.data.model.MediaSlideEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ResolutionType

/**
 * FFmpeg Video Render Pipeline Generator.
 * Compiles project timeline, Ken Burns motion filters, audio tracks, and color grading
 * into production-ready FFmpeg command lines for local or cloud rendering.
 */
object FFmpegRenderPipeline {

    fun generateKenBurnsFilter(motion: KenBurnsMotion, fps: Int, durationSec: Float, outWidth: Int, outHeight: Int): String {
        val totalFrames = (fps * durationSec).toInt().coerceAtLeast(24)
        return when (motion) {
            KenBurnsMotion.SLOW_ZOOM_IN ->
                "zoompan=z='min(zoom+0.0015,1.35)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=$totalFrames:s=${outWidth}x${outHeight}:fps=$fps"
            KenBurnsMotion.SLOW_ZOOM_OUT ->
                "zoompan=z='if(lte(zoom,1.0),1.35,max(1.001,zoom-0.0015))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=$totalFrames:s=${outWidth}x${outHeight}:fps=$fps"
            KenBurnsMotion.PAN_LEFT_TO_RIGHT ->
                "zoompan=z=1.20:x='if(lte(on,-1),(iw-iw/zoom)/2,x+1.5)':y='ih/2-(ih/zoom/2)':d=$totalFrames:s=${outWidth}x${outHeight}:fps=$fps"
            KenBurnsMotion.PAN_RIGHT_TO_LEFT ->
                "zoompan=z=1.20:x='if(lte(on,-1),(iw-iw/zoom),x-1.5)':y='ih/2-(ih/zoom/2)':d=$totalFrames:s=${outWidth}x${outHeight}:fps=$fps"
            KenBurnsMotion.DRAMATIC_PUSH ->
                "zoompan=z='min(zoom+0.0035,1.55)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=$totalFrames:s=${outWidth}x${outHeight}:fps=$fps"
            KenBurnsMotion.STATIC_LOCKED ->
                "scale=${outWidth}:${outHeight}:force_original_aspect_ratio=increase,crop=${outWidth}:${outHeight},fps=$fps"
        }
    }

    fun generateColorGradingFilter(presetName: String): String {
        val preset = runCatching { ColorGradingPreset.valueOf(presetName) }.getOrDefault(ColorGradingPreset.CLEAN_NATURAL)
        return when (preset) {
            ColorGradingPreset.CINEMATIC_NOIR -> "hue=s=0,eq=contrast=1.35:brightness=-0.05"
            ColorGradingPreset.WARM_DOCUMENTARY -> "eq=contrast=1.15:brightness=0.02,colorbalance=rs=0.1:gs=0.04:bs=-0.08"
            ColorGradingPreset.VINTAGE_70S -> "eq=contrast=1.1:saturation=0.85,colorbalance=rs=0.05:gs=0.05:bs=-0.1"
            ColorGradingPreset.TEAL_AND_ORANGE -> "eq=contrast=1.2:saturation=1.15,colorbalance=rs=0.15:gs=0.02:bs=-0.1:rh=-0.1:gh=0.05:bh=0.15"
            ColorGradingPreset.BLEACH_BYPASS -> "eq=contrast=1.4:saturation=0.55:brightness=-0.03"
            ColorGradingPreset.KODAK_FILM -> "eq=contrast=1.2:saturation=1.1,colorbalance=rs=0.08:gs=0.02:bs=-0.04"
            ColorGradingPreset.CLEAN_NATURAL -> "null"
        }
    }

    fun buildFullCommand(project: ProjectEntity, slides: List<MediaSlideEntity>): String {
        val aspect = runCatching { AspectRatioType.valueOf(project.aspectRatio) }.getOrDefault(AspectRatioType.LANDSCAPE_16_9)
        val res = runCatching { ResolutionType.valueOf(project.resolution) }.getOrDefault(ResolutionType.RES_1080P)

        val outWidth: Int
        val outHeight: Int
        when (aspect) {
            AspectRatioType.SHORTS_9_16 -> {
                outWidth = if (res == ResolutionType.RES_4K) 2160 else 1080
                outHeight = if (res == ResolutionType.RES_4K) 3840 else 1920
            }
            AspectRatioType.SQUARE_1_1 -> {
                outWidth = if (res == ResolutionType.RES_4K) 2160 else 1080
                outHeight = outWidth
            }
            AspectRatioType.LANDSCAPE_16_9 -> {
                outWidth = if (res == ResolutionType.RES_4K) 3840 else 1920
                outHeight = if (res == ResolutionType.RES_4K) 2160 else 1080
            }
        }

        val fps = 24
        val sb = StringBuilder("ffmpeg \\\n")

        // Input slides
        slides.forEachIndexed { i, slide ->
            sb.append("  -loop 1 -t ${slide.durationSeconds} -i slide_${i + 1}.jpg \\\n")
        }

        // Voiceover audio input if present
        if (!project.voiceAudioFileName.isNullOrEmpty()) {
            sb.append("  -i ${project.voiceAudioFileName} \\\n")
        }

        // Background music input
        sb.append("  -i bgm_${project.bgmPresetId}.mp3 \\\n")

        // Filter graph start
        sb.append("  -filter_complex \"\\\n")

        // Apply Ken Burns & Color grading to each visual slide
        val colorFilter = generateColorGradingFilter(project.colorGradingPreset)
        slides.forEachIndexed { i, slide ->
            val motion = runCatching { KenBurnsMotion.valueOf(slide.kenBurnsMotion) }.getOrDefault(KenBurnsMotion.SLOW_ZOOM_IN)
            val kb = generateKenBurnsFilter(motion, fps, slide.durationSeconds, outWidth, outHeight)
            val fullFilter = if (colorFilter != "null") "$kb,$colorFilter" else kb
            sb.append("    [$i:v]$fullFilter[v$i]; \\\n")
        }

        // Concat slides
        val concatInputs = (0 until slides.size).joinToString("") { "[v$it]" }
        sb.append("    $concatInputs concat=n=${slides.size}:v=1:a=0[vconcat]; \\\n")

        // Audio mix filter (voiceover ducking under BGM)
        val audioVoiceIdx = if (!project.voiceAudioFileName.isNullOrEmpty()) slides.size else -1
        val audioBgmIdx = if (audioVoiceIdx >= 0) slides.size + 1 else slides.size

        if (audioVoiceIdx >= 0) {
            val bgmVol = project.bgmVolume
            val voiceVol = project.voiceVolume
            sb.append("    [$audioVoiceIdx:a]volume=$voiceVol[voice]; \\\n")
            sb.append("    [$audioBgmIdx:a]volume=$bgmVol[bgm]; \\\n")
            sb.append("    [voice][bgm]amix=inputs=2:duration=first:dropout_transition=2[aout]\" \\\n")
            sb.append("  -map \"[vconcat]\" -map \"[aout]\" \\\n")
        } else {
            sb.append("    [$audioBgmIdx:a]volume=${project.bgmVolume}[aout]\" \\\n")
            sb.append("  -map \"[vconcat]\" -map \"[aout]\" \\\n")
        }

        // Codec & Output
        val codec = if (project.codec.contains("HEVC", ignoreCase = true)) "libx265 -crf 22" else "libx264 -crf 20 -preset medium"
        sb.append("  -c:v $codec -pix_fmt yuv420p \\\n")
        sb.append("  -c:a aac -b:a 192k \\\n")
        sb.append("  -r $fps \\\n")
        sb.append("  output_documentary_${project.id}.mp4")

        return sb.toString()
    }
}
