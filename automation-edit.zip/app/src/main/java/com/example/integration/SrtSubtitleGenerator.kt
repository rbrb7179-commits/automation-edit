package com.example.integration

import android.content.Context
import com.example.data.model.MediaSlideEntity
import java.io.File

/**
 * Standard SubRip (.srt) Subtitle Generator.
 * Converts timeline slides and speech recognition word/sentence timestamps
 * into valid SubRip subtitle format for video players and FFmpeg rendering.
 */
object SrtSubtitleGenerator {

    /**
     * Formats milliseconds into standard SRT timecode: HH:MM:SS,mmm
     */
    fun formatSrtTimecode(millis: Long): String {
        val totalSec = millis / 1000
        val ms = millis % 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return String.format("%02d:%02d:%02d,%03d", hours, minutes, seconds, ms)
    }

    /**
     * Generates a full .srt string from a list of slides.
     */
    fun generateSrt(slides: List<MediaSlideEntity>): String {
        val sb = StringBuilder()
        var currentMs = 0L
        var index = 1

        slides.forEach { slide ->
            val durationMs = (slide.durationSeconds * 1000).toLong().coerceAtLeast(500L)
            val startMs = currentMs
            val endMs = startMs + durationMs

            val text = slide.captionSnippet.trim().ifEmpty {
                slide.title.trim()
            }

            if (text.isNotBlank()) {
                sb.append(index).append("\n")
                sb.append(formatSrtTimecode(startMs))
                    .append(" --> ")
                    .append(formatSrtTimecode(endMs))
                    .append("\n")
                sb.append(text).append("\n\n")
                index++
            }
            currentMs = endMs
        }

        return sb.toString().trimEnd() + "\n"
    }

    /**
     * Saves the generated SRT content to a file in the app cache directory.
     */
    fun saveSrtToFile(context: Context, projectId: Long, srtContent: String): File {
        val exportDir = File(context.cacheDir, "subtitles").apply { mkdirs() }
        val srtFile = File(exportDir, "subtitles_project_$projectId.srt")
        srtFile.writeText(srtContent)
        return srtFile
    }
}
